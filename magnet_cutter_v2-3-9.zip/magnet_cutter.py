bl_info = {
    "name": "Magnet Hole Cutter",
    "author": "SprueGuild@gmail.com",
    "version": (2, 3, 9),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar (N) > Magnet Tool",
    "description": "Multi-shape magnet cutter (Disc, Ball Bearing, Ball Cup + Magnet, Ring/Plug, Bar) with concave centering, axis lock, and homogeneous counterpart matching",
    "category": "Mesh",
    "type": "extension",
}

import os
import sys
import shutil
import importlib
import math
import bpy
import bmesh
from mathutils import Vector, Matrix, Quaternion
from bpy.props import EnumProperty, FloatProperty, BoolProperty, IntProperty
from bpy_extras import view3d_utils
import gpu
from gpu_extras.batch import batch_for_shader


# =========================================================================
# CONSTANTS & METADATA TAGS
# =========================================================================
COLLECTION_NAME = "Magnet Hole Cutters"
LEGACY_COLLECTION_NAME = "Magnet Cutters"
MODIFIER_PREFIX = "Magnet_Cut"

DNS_KEY_2D_HANDLER = "_magnet_cutter_2d_handler"
DNS_KEY_3D_HANDLER = "_magnet_cutter_3d_handler"

TAG_IS_CUTTER = "is_magnet_cutter"
TAG_TARGET_NAME = "target_obj_name"
TAG_MODIFIER_NAME = "modifier_name"
TAG_SHAPE = "shape_type"
TAG_RING_MODE = "ring_mode"
TAG_RADIUS = "radius"
TAG_INNER_RADIUS = "inner_radius"
TAG_BALL_DIAMETER = "ball_diameter"
TAG_BALL_RADIUS = "ball_radius"
TAG_CUP_DEPTH = "cup_depth"
TAG_MAGNET_DEPTH = "magnet_depth"
TAG_BAR_LENGTH = "bar_length"
TAG_DEPTH = "depth"
TAG_OVERSHOOT = "overshoot"
TAG_SEGMENTS = "segments"
TAG_CHAMFER = "chamfer"
TAG_GLUE_RELIEF = "glue_relief"
TAG_HIT_LOC = "hit_loc"
TAG_HIT_NORMAL = "hit_normal"
TAG_AXIS_NORMAL = "axis_normal"
TAG_PEG_OBJ = "peg_obj_name"
TAG_PARENT_CUTTER = "parent_cutter_name"
TAG_IS_PEG = "is_companion_peg"
TAG_COUNTERPART_DEPTH = "counterpart_depth"

PRESET_DIMENSIONS = {
    "2x2": (2.0, 2.0),
    "3x2": (3.0, 2.0),
    "4x2": (4.0, 2.0),
    "5x2": (5.0, 2.0),
    "6x2": (6.0, 2.0),
    "2x1": (2.0, 1.0),
    "3x1": (3.0, 1.0),
}


# =========================================================================
# 2D CURSOR RETICLE HUD (UNIT BATCH + GPU MATRIX TRANSLATION, POST_PIXEL)
# =========================================================================
class ReticleHUD:
    _mouse_pos = (-999.0, -999.0)
    _batches = None
    _shader = None

    @classmethod
    def get_shader(cls):
        if cls._shader is None:
            shader_name = 'UNIFORM_COLOR' if bpy.app.version >= (4, 0, 0) else '2D_UNIFORM_COLOR'
            cls._shader = gpu.shader.from_builtin(shader_name)
        return cls._shader

    @classmethod
    def update_position(cls, x, y):
        cls._mouse_pos = (float(x), float(y))

    @classmethod
    def _build_origin_ring_batch(cls, shader, radius, segments):
        step = (2.0 * math.pi) / segments
        coords = [
            (math.cos(i * step) * radius, math.sin(i * step) * radius)
            for i in range(segments + 1)
        ]
        return batch_for_shader(shader, 'LINE_STRIP', {"pos": coords})

    @classmethod
    def _get_batches(cls, shader):
        if cls._batches is None:
            cls._batches = (
                cls._build_origin_ring_batch(shader, 22.0, 28),
                cls._build_origin_ring_batch(shader, 14.0, 28),
                cls._build_origin_ring_batch(shader, 2.5, 12),
            )
        return cls._batches

    @classmethod
    def _draw_callback(cls):
        wm = bpy.context.window_manager
        if not getattr(wm, "magnet_active", False):
            cls.disable()
            return

        cx, cy = cls._mouse_pos
        if cx < 0.0 or cy < 0.0:
            return

        shader = cls.get_shader()
        if shader is None:
            return

        outer_batch, inner_batch, dot_batch = cls._get_batches(shader)

        gpu.state.blend_set('ALPHA')
        try:
            with gpu.matrix.push_pop():
                gpu.matrix.translate((cx, cy))
                shader.bind()

                shader.uniform_float("color", (0.0, 0.85, 1.0, 0.35))
                outer_batch.draw(shader)

                shader.uniform_float("color", (0.0, 0.95, 1.0, 0.95))
                inner_batch.draw(shader)

                shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
                dot_batch.draw(shader)
        finally:
            gpu.state.blend_set('NONE')

    @classmethod
    def enable(cls):
        cls.disable()
        handler = bpy.types.SpaceView3D.draw_handler_add(
            cls._draw_callback, (), 'WINDOW', 'POST_PIXEL'
        )
        bpy.app.driver_namespace[DNS_KEY_2D_HANDLER] = handler

    @classmethod
    def disable(cls):
        handler = bpy.app.driver_namespace.pop(DNS_KEY_2D_HANDLER, None)
        if handler is not None:
            bpy.types.SpaceView3D.draw_handler_remove(handler, 'WINDOW')
        cls._mouse_pos = (-999.0, -999.0)


# =========================================================================
# 3D SURFACE INTERSECTION RING & SHADOW OVERLAY (LOCAL-SPACE GPU BATCHES)
# =========================================================================
class CutterOverlay3D:
    _shader = None
    _local_batch_cache = {}

    @classmethod
    def get_shader(cls):
        if cls._shader is None:
            shader_name = 'UNIFORM_COLOR' if bpy.app.version >= (4, 0, 0) else '3D_UNIFORM_COLOR'
            cls._shader = gpu.shader.from_builtin(shader_name)
        return cls._shader

    @classmethod
    def invalidate_cache(cls, cutter_name=None):
        if cutter_name is None:
            cls._local_batch_cache.clear()

    @classmethod
    def _build_local_batches(cls, shader, shape_type, ring_mode, radius, inner_radius, bar_len, depth, overshoot, ring_segs, ball_radius=1.5, cup_depth=1.0, counterpart_depth=1.0):
        """
        Compiles GPUBatch objects in cutter local space (centered at origin).
        Supports CYLINDER, SPHERE, BALL_SOCKET, RING (Donut/Full/Plug), and BAR shapes.
        """
        total_height = depth + overshoot
        z_surface = (depth - overshoot) * 0.5
        z_end = -total_height * 0.5

        surface_ring_pts = []
        halo_ring_pts = []
        inner_ring_pts = []
        depth_guide_lines = []
        tick_lines = []
        wall_tris = []

        if shape_type == 'BAR':
            hx = radius
            hy = bar_len * 0.5
            hx_s = hx * 1.004
            hy_s = hy * 1.004
            hx_h = hx * 1.035
            hy_h = hy * 1.035

            surface_ring_pts = [
                (-hx_s, -hy_s, z_surface), (hx_s, -hy_s, z_surface),
                (hx_s, hy_s, z_surface), (-hx_s, hy_s, z_surface),
                (-hx_s, -hy_s, z_surface),
            ]
            halo_ring_pts = [
                (-hx_h, -hy_h, z_surface), (hx_h, -hy_h, z_surface),
                (hx_h, hy_h, z_surface), (-hx_h, hy_h, z_surface),
                (-hx_h, -hy_h, z_surface),
            ]
            bot_corners = [
                (-hx, -hy, z_end), (hx, -hy, z_end),
                (hx, hy, z_end), (-hx, hy, z_end),
            ]
            surf_corners = [
                (-hx_s, -hy_s, z_surface), (hx_s, -hy_s, z_surface),
                (hx_s, hy_s, z_surface), (-hx_s, hy_s, z_surface),
            ]
            for i in range(4):
                b0 = bot_corners[i]
                b1 = bot_corners[(i + 1) % 4]
                s0 = surf_corners[i]
                s1 = surf_corners[(i + 1) % 4]
                depth_guide_lines.extend([b0, b1, b0, s0])
                wall_tris.extend([b0, b1, s1, b0, s1, s0])

            cross_x = hx * 0.25
            cross_y = hy * 0.25
            depth_guide_lines.extend([
                (-cross_x, 0.0, z_end), (cross_x, 0.0, z_end),
                (0.0, -cross_y, z_end), (0.0, cross_y, z_end),
            ])
            tick_lines.extend([
                (-hx * 1.15, 0.0, z_surface), (-hx * 0.94, 0.0, z_surface),
                (hx * 0.94, 0.0, z_surface), (hx * 1.15, 0.0, z_surface),
                (0.0, -hy * 1.15, z_surface), (0.0, -hy * 0.94, z_surface),
                (0.0, hy * 0.94, z_surface), (0.0, hy * 1.15, z_surface),
            ])
        elif shape_type == 'BALL_SOCKET':
            z_apex = z_surface - cup_depth
            z_sphere_c = z_apex + ball_radius
            dz_s = z_surface - z_sphere_c
            if abs(dz_s) < ball_radius:
                surf_base_r = math.sqrt(max(0.01, ball_radius * ball_radius - dz_s * dz_s))
            else:
                surf_base_r = ball_radius

            r_surf = surf_base_r * 1.004
            r_halo = surf_base_r * 1.032
            r_mag = radius
            step = (2.0 * math.pi) / ring_segs

            if ball_radius > r_mag:
                dz_t = -math.sqrt(ball_radius * ball_radius - r_mag * r_mag)
                z_trans = max(z_end, z_sphere_c + dz_t)
            else:
                z_trans = z_apex

            bottom_ring_pts = []
            mid_ring_pts = []
            for i in range(ring_segs + 1):
                angle = i * step
                ca = math.cos(angle)
                sa = math.sin(angle)

                surface_ring_pts.append((ca * r_surf, sa * r_surf, z_surface))
                halo_ring_pts.append((ca * r_halo, sa * r_halo, z_surface))
                bottom_ring_pts.append((ca * r_mag, sa * r_mag, z_end))
                inner_ring_pts.append((ca * r_mag, sa * r_mag, z_trans))
                mid_ring_pts.append((ca * r_mag, sa * r_mag, z_trans))

            for i in range(ring_segs):
                depth_guide_lines.append(bottom_ring_pts[i])
                depth_guide_lines.append(bottom_ring_pts[i + 1])
                b0 = bottom_ring_pts[i]
                b1 = bottom_ring_pts[i + 1]
                m0 = mid_ring_pts[i]
                m1 = mid_ring_pts[i + 1]
                s0 = surface_ring_pts[i]
                s1 = surface_ring_pts[i + 1]
                wall_tris.extend([b0, b1, m1, b0, m1, m0])
                wall_tris.extend([m0, m1, s1, m0, s1, s0])

            arc_steps = 10
            for q in range(4):
                qa = q * (math.pi * 0.5)
                qca, qsa = math.cos(qa), math.sin(qa)
                depth_guide_lines.extend([
                    (qca * r_mag, qsa * r_mag, z_end),
                    (qca * r_mag, qsa * r_mag, z_trans),
                ])
                prev_pt = (qca * r_mag, qsa * r_mag, z_trans)
                for s_idx in range(1, arc_steps + 1):
                    zz = z_trans + (s_idx / arc_steps) * (z_surface - z_trans)
                    dz = zz - z_sphere_c
                    if dz < 0.0:
                        rr = math.sqrt(max(0.01, ball_radius * ball_radius - dz * dz))
                    else:
                        rr = ball_radius
                    cur_pt = (qca * max(r_mag, rr), qsa * max(r_mag, rr), zz)
                    depth_guide_lines.extend([prev_pt, cur_pt])
                    prev_pt = cur_pt

            cross_r = r_mag * 0.22
            depth_guide_lines.extend([
                (-cross_r, 0.0, z_end), (cross_r, 0.0, z_end),
                (0.0, -cross_r, z_end), (0.0, cross_r, z_end),
            ])

            for t in range(8):
                ta = t * (math.pi * 0.25)
                tca = math.cos(ta)
                tsa = math.sin(ta)
                tick_lines.append((tca * surf_base_r * 0.95, tsa * surf_base_r * 0.95, z_surface))
                tick_lines.append((tca * surf_base_r * 1.14, tsa * surf_base_r * 1.14, z_surface))
        else:
            eff_r = radius
            # If shallow sphere (depth < radius), surface opening radius is the chord radius on the sphere
            if shape_type == 'SPHERE' and depth < eff_r:
                z_sphere_center = z_end + eff_r
                dz = z_surface - z_sphere_center
                surf_base_r = math.sqrt(max(0.01, eff_r * eff_r - dz * dz))
            else:
                surf_base_r = eff_r

            r_surf = surf_base_r * 1.004
            r_halo = surf_base_r * 1.032
            step = (2.0 * math.pi) / ring_segs

            bottom_ring_pts = []
            for i in range(ring_segs + 1):
                angle = i * step
                ca = math.cos(angle)
                sa = math.sin(angle)

                surface_ring_pts.append((ca * r_surf, sa * r_surf, z_surface))
                halo_ring_pts.append((ca * r_halo, sa * r_halo, z_surface))
                bottom_ring_pts.append((ca * eff_r, sa * eff_r, z_end))
                if shape_type == 'RING' and ring_mode in {'DONUT', 'PLUG'}:
                    inner_ring_pts.append((ca * inner_radius, sa * inner_radius, z_surface))

            for i in range(ring_segs):
                if shape_type != 'SPHERE':
                    depth_guide_lines.append(bottom_ring_pts[i])
                    depth_guide_lines.append(bottom_ring_pts[i + 1])
                b0 = bottom_ring_pts[i]
                b1 = bottom_ring_pts[i + 1]
                s0 = surface_ring_pts[i]
                s1 = surface_ring_pts[i + 1]
                wall_tris.extend([b0, b1, s1, b0, s1, s0])

            # 4 Vertical/Curved Depth Ribs
            if shape_type == 'SPHERE':
                z_sphere_c = z_end + eff_r
                arc_steps = 10
                for q in range(4):
                    qa = q * (math.pi * 0.5)
                    qca, qsa = math.cos(qa), math.sin(qa)
                    prev_pt = (0.0, 0.0, z_end)
                    for s_idx in range(1, arc_steps + 1):
                        theta = (s_idx / arc_steps) * (math.pi * 0.5)
                        rr = math.sin(theta) * eff_r
                        zz = z_sphere_c - math.cos(theta) * eff_r
                        if zz > z_surface:
                            zz = z_surface
                            rr = surf_base_r
                        cur_pt = (qca * rr, qsa * rr, zz)
                        depth_guide_lines.extend([prev_pt, cur_pt])
                        prev_pt = cur_pt
                    if z_surface > z_sphere_c:
                        depth_guide_lines.extend([
                            (qca * eff_r, qsa * eff_r, z_sphere_c),
                            (qca * surf_base_r, qsa * surf_base_r, z_surface),
                        ])
            else:
                for q in range(4):
                    idx = (q * ring_segs) // 4
                    depth_guide_lines.append(bottom_ring_pts[idx])
                    depth_guide_lines.append(surface_ring_pts[idx])

            if shape_type == 'RING' and ring_mode in {'DONUT', 'PLUG'}:
                for i in range(ring_segs):
                    p0 = (inner_ring_pts[i][0], inner_ring_pts[i][1], z_end)
                    p1 = (inner_ring_pts[i + 1][0], inner_ring_pts[i + 1][1], z_end)
                    depth_guide_lines.extend([p0, p1])

            if shape_type == 'RING' and ring_mode == 'PLUG':
                z_peg_top = z_surface + counterpart_depth
                for i in range(ring_segs):
                    ca = math.cos(i * step)
                    sa = math.sin(i * step)
                    ca_next = math.cos((i + 1) * step)
                    sa_next = math.sin((i + 1) * step)
                    depth_guide_lines.extend([
                        (ca * inner_radius, sa * inner_radius, z_peg_top),
                        (ca_next * inner_radius, sa_next * inner_radius, z_peg_top),
                    ])
                for q in range(4):
                    qa = q * (math.pi * 0.5)
                    qca, qsa = math.cos(qa), math.sin(qa)
                    depth_guide_lines.extend([
                        (qca * inner_radius, qsa * inner_radius, z_end),
                        (qca * inner_radius, qsa * inner_radius, z_peg_top),
                    ])

            cross_r = eff_r * 0.22
            depth_guide_lines.extend([
                (-cross_r, 0.0, z_end), (cross_r, 0.0, z_end),
                (0.0, -cross_r, z_end), (0.0, cross_r, z_end),
            ])

            for t in range(8):
                ta = t * (math.pi * 0.25)
                tca = math.cos(ta)
                tsa = math.sin(ta)
                tick_lines.append((tca * surf_base_r * 0.95, tsa * surf_base_r * 0.95, z_surface))
                tick_lines.append((tca * surf_base_r * 1.14, tsa * surf_base_r * 1.14, z_surface))

        return {
            "surface_ring": batch_for_shader(shader, 'LINE_STRIP', {"pos": surface_ring_pts}),
            "halo_ring": batch_for_shader(shader, 'LINE_STRIP', {"pos": halo_ring_pts}),
            "inner_ring": batch_for_shader(shader, 'LINE_STRIP', {"pos": inner_ring_pts}) if inner_ring_pts else None,
            "ticks": batch_for_shader(shader, 'LINES', {"pos": tick_lines}),
            "depth_guides": batch_for_shader(shader, 'LINES', {"pos": depth_guide_lines}),
            "wall_tris": batch_for_shader(shader, 'TRIS', {"pos": wall_tris}),
        }

    @classmethod
    def _get_local_batches(cls, shader, cutter):
        shape_type = str(cutter.get(TAG_SHAPE, 'CYLINDER'))
        ring_mode = str(cutter.get(TAG_RING_MODE, 'DONUT'))
        radius = round(float(cutter.get(TAG_RADIUS, 1.6)), 4)
        inner_radius = round(float(cutter.get(TAG_INNER_RADIUS, 0.7)), 4)
        ball_radius = round(float(cutter.get(TAG_BALL_RADIUS, 1.5)), 4)
        cup_depth = round(float(cutter.get(TAG_CUP_DEPTH, 1.0)), 4)
        bar_len = round(float(cutter.get(TAG_BAR_LENGTH, 4.0)), 4)
        depth = round(float(cutter.get(TAG_DEPTH, 2.3)), 4)
        overshoot = round(float(cutter.get(TAG_OVERSHOOT, 0.25)), 4)
        ring_segs = max(24, min(48, int(cutter.get(TAG_SEGMENTS, 36))))
        counterpart_depth = round(float(cutter.get(TAG_COUNTERPART_DEPTH, depth)), 4)

        key = (shape_type, ring_mode, radius, inner_radius, ball_radius, cup_depth, bar_len, depth, overshoot, ring_segs, counterpart_depth)
        batches = cls._local_batch_cache.get(key)
        if batches is None:
            if len(cls._local_batch_cache) > 24:
                cls._local_batch_cache.clear()
            batches = cls._build_local_batches(
                shader, shape_type, ring_mode, radius, inner_radius, bar_len, depth, overshoot, ring_segs,
                ball_radius=ball_radius, cup_depth=cup_depth, counterpart_depth=counterpart_depth
            )
            cls._local_batch_cache[key] = batches
        return batches

    @classmethod
    def _draw_callback(cls):
        context = bpy.context
        space = getattr(context, "space_data", None)
        if space is not None and hasattr(space, "overlay") and not space.overlay.show_overlays:
            return

        scene = getattr(context, "scene", None)
        if scene is None or not hasattr(scene, "magnet_props"):
            return

        col = bpy.data.collections.get(COLLECTION_NAME)
        if col is None or len(col.objects) == 0:
            return

        props = scene.magnet_props
        show_ring = props.show_surface_ring
        is_shadow_mode = (props.display_mode == 'SHADOW')
        if not show_ring and not is_shadow_mode:
            return

        shader = cls.get_shader()
        if shader is None:
            return

        active_obj = getattr(context, "active_object", None)
        gpu.state.blend_set('ALPHA')
        try:
            shader.bind()
            for cutter in col.objects:
                if not cutter.get(TAG_IS_CUTTER, False) or cutter.hide_get() or cutter.get(TAG_IS_PEG, False):
                    continue

                is_selected = (cutter == active_obj) or cutter.select_get()
                is_plug = (cutter.get(TAG_SHAPE, 'CYLINDER') == 'RING' and cutter.get(TAG_RING_MODE, 'DONUT') == 'PLUG')
                batches = cls._get_local_batches(shader, cutter)

                with gpu.matrix.push_pop():
                    gpu.matrix.multiply_matrix(cutter.matrix_world)

                    if is_shadow_mode:
                        gpu.state.depth_test_set('LESS_EQUAL')
                        if is_plug:
                            shader.uniform_float("color", (0.12, 0.55, 0.35, 0.36 if is_selected else 0.22))
                        else:
                            shader.uniform_float("color", (0.03, 0.05, 0.08, 0.36 if is_selected else 0.22))
                        batches["wall_tris"].draw(shader)

                    if show_ring:
                        gpu.state.depth_test_set('ALWAYS')

                        shader.uniform_float("color", (0.18, 0.72, 1.0, 0.48 if is_selected else 0.24))
                        batches["depth_guides"].draw(shader)

                        shader.uniform_float("color", (1.0, 0.82, 0.22, 0.90 if is_selected else 0.45))
                        batches["ticks"].draw(shader)

                        shader.uniform_float("color", (0.0, 0.85, 1.0, 0.32 if is_selected else 0.16))
                        batches["halo_ring"].draw(shader)

                        if batches["inner_ring"] is not None:
                            shader.uniform_float("color", (1.0, 0.55, 0.15, 0.92 if is_selected else 0.55))
                            batches["inner_ring"].draw(shader)

                        ring_col = (
                            (0.25, 1.0, 0.55, 0.98) if is_plug
                            else ((0.0, 1.0, 0.92, 0.98) if is_selected else (0.0, 0.85, 0.95, 0.70))
                        )
                        shader.uniform_float("color", ring_col)
                        batches["surface_ring"].draw(shader)
        finally:
            gpu.state.depth_test_set('NONE')
            gpu.state.blend_set('NONE')

    @classmethod
    def enable(cls):
        if bpy.app.driver_namespace.get(DNS_KEY_3D_HANDLER) is None:
            handler = bpy.types.SpaceView3D.draw_handler_add(
                cls._draw_callback, (), 'WINDOW', 'POST_VIEW'
            )
            bpy.app.driver_namespace[DNS_KEY_3D_HANDLER] = handler

    @classmethod
    def disable(cls):
        handler = bpy.app.driver_namespace.pop(DNS_KEY_3D_HANDLER, None)
        if handler is not None:
            bpy.types.SpaceView3D.draw_handler_remove(handler, 'WINDOW')
        cls._local_batch_cache.clear()


# =========================================================================
# SCENE, SCALE & CLEANUP HELPERS
# =========================================================================
def get_or_create_cutter_collection(context):
    col = bpy.data.collections.get(COLLECTION_NAME)
    if col is None:
        col = bpy.data.collections.new(COLLECTION_NAME)
        context.scene.collection.children.link(col)
    return col


def find_associated_pegs(cutter_obj):
    """Finds all peg objects belonging to a cutter by tag, child hierarchy, or name pattern."""
    pegs = []
    peg_name = cutter_obj.get(TAG_PEG_OBJ, "")
    if peg_name:
        p = bpy.data.objects.get(peg_name)
        if p is not None and p not in pegs:
            pegs.append(p)

    for child in list(cutter_obj.children):
        if child.get(TAG_IS_PEG, False) or child.name.endswith("_Peg"):
            if child not in pegs:
                pegs.append(child)

    for obj in list(bpy.data.objects):
        if obj.get(TAG_IS_PEG, False) or (obj.get(TAG_IS_CUTTER, False) and obj.name.endswith("_Peg")):
            if obj.get(TAG_PARENT_CUTTER, "") == cutter_obj.name:
                if obj not in pegs:
                    pegs.append(obj)

    return pegs


def delete_cutter_and_associated_pegs(cutter):
    """Safely and completely deletes a cutter, all its associated pegs, and their modifiers."""
    target_obj = bpy.data.objects.get(cutter.get(TAG_TARGET_NAME, ""))
    mod_name = cutter.get(TAG_MODIFIER_NAME, "")

    pegs = find_associated_pegs(cutter)

    if target_obj is not None:
        if mod_name and mod_name in target_obj.modifiers:
            target_obj.modifiers.remove(target_obj.modifiers[mod_name])
        for p in pegs:
            p_mod_name = p.get(TAG_MODIFIER_NAME, "")
            if p_mod_name and p_mod_name in target_obj.modifiers:
                target_obj.modifiers.remove(target_obj.modifiers[p_mod_name])
        for m in list(target_obj.modifiers):
            if m.type == 'BOOLEAN' and m.object in ({cutter} | set(pegs)):
                target_obj.modifiers.remove(m)

    for p in pegs:
        p_mesh = p.data
        bpy.data.objects.remove(p, do_unlink=True)
        if p_mesh is not None and p_mesh.users == 0:
            bpy.data.meshes.remove(p_mesh)

    mesh_data = cutter.data
    bpy.data.objects.remove(cutter, do_unlink=True)
    if mesh_data is not None and mesh_data.users == 0:
        bpy.data.meshes.remove(mesh_data)


def cleanup_orphan_modifiers_and_collections():
    """Explicitly removes any Magnet_Cut Boolean modifiers and orphan peg objects whose cutter was deleted."""
    # 1. Purge any orphan peg objects whose parent cutter is missing or deleted
    orphan_pegs = []
    for obj in list(bpy.data.objects):
        if obj.get(TAG_IS_PEG, False) or (obj.get(TAG_IS_CUTTER, False) and obj.name.endswith("_Peg")):
            parent_name = obj.get(TAG_PARENT_CUTTER, "")
            parent_obj = obj.parent
            parent_exists = (
                (parent_obj is not None and parent_obj.name in bpy.data.objects and parent_obj.get(TAG_IS_CUTTER, False))
                or (parent_name and parent_name in bpy.data.objects and bpy.data.objects[parent_name].get(TAG_IS_CUTTER, False))
            )
            if not parent_exists:
                orphan_pegs.append(obj)

    for p in orphan_pegs:
        for target in list(bpy.data.objects):
            if target.type == 'MESH':
                for mod in list(target.modifiers):
                    if mod.type == 'BOOLEAN' and (mod.object == p or mod.name.endswith("_Peg")):
                        if mod.object == p or mod.object is None or mod.object in orphan_pegs:
                            target.modifiers.remove(mod)
        p_mesh = p.data
        bpy.data.objects.remove(p, do_unlink=True)
        if p_mesh is not None and p_mesh.users == 0:
            bpy.data.meshes.remove(p_mesh)

    # 2. Purge leftover Boolean modifiers pointing to missing/deleted cutter objects
    for obj in bpy.data.objects:
        if obj.type == 'MESH' and not obj.get(TAG_IS_CUTTER, False):
            for mod in list(obj.modifiers):
                if mod.type == 'BOOLEAN' and mod.name.startswith(MODIFIER_PREFIX):
                    if mod.object is None or mod.object.name not in bpy.data.objects:
                        obj.modifiers.remove(mod)
                    else:
                        if hasattr(mod, "use_self") and mod.use_self:
                            mod.use_self = False
                        if hasattr(mod, "use_hole_tolerant") and mod.use_hole_tolerant:
                            mod.use_hole_tolerant = False

    # 3. Clean up empty cutter collections
    for col_name in (LEGACY_COLLECTION_NAME, COLLECTION_NAME):
        col = bpy.data.collections.get(col_name)
        if col is not None and len(col.objects) == 0:
            bpy.data.collections.remove(col)


def on_depsgraph_auto_clean_orphans(scene, depsgraph):
    """
    Ultra-light guardian: quickly detects if a plug cutter was deleted
    natively (via X / Delete in 3D Viewport or Outliner), and purges its
    orphan peg and modifier without graphical stalls.
    """
    col = bpy.data.collections.get(COLLECTION_NAME)
    if col is None or len(col.objects) == 0:
        return

    has_orphan_peg = False
    for obj in col.objects:
        if obj.get(TAG_IS_PEG, False) or (obj.get(TAG_IS_CUTTER, False) and obj.name.endswith("_Peg")):
            parent_name = obj.get(TAG_PARENT_CUTTER, "")
            parent_obj = obj.parent
            if parent_obj is None or (parent_name and parent_name not in bpy.data.objects):
                has_orphan_peg = True
                break

    if has_orphan_peg:
        cleanup_orphan_modifiers_and_collections()


def purge_legacy_handlers_and_heal_scene():
    for handler in list(bpy.app.handlers.depsgraph_update_post):
        h_name = getattr(handler, "__name__", "")
        if h_name == "on_depsgraph_update_cleanup" or ("magnet" in h_name.lower() and h_name != "on_depsgraph_auto_clean_orphans"):
            bpy.app.handlers.depsgraph_update_post.remove(handler)

    if not hasattr(bpy.data, "objects") or not hasattr(bpy.data, "collections"):
        return

    legacy_col = bpy.data.collections.get(LEGACY_COLLECTION_NAME)
    if legacy_col is not None:
        new_col = bpy.data.collections.get(COLLECTION_NAME)
        if new_col is None and len(legacy_col.objects) > 0:
            new_col = bpy.data.collections.new(COLLECTION_NAME)
            if bpy.context.scene is not None:
                bpy.context.scene.collection.children.link(new_col)

        for obj in list(legacy_col.objects):
            legacy_col.objects.unlink(obj)
            if new_col is not None and obj.name not in new_col.objects:
                new_col.objects.link(obj)

        bpy.data.collections.remove(legacy_col)

    cleanup_orphan_modifiers_and_collections()


def resolve_unit_scale(context, target_obj=None):
    props = context.scene.magnet_props
    mode = props.scale_mode

    if mode == 'MM':
        return 1.0, "Scale: Millimeters (1 unit = 1mm)"
    if mode == 'M':
        return 0.001, "Scale: Meters (1 unit = 1m)"

    if target_obj is not None and target_obj.type == 'MESH':
        dims = target_obj.dimensions
        max_extent = max(dims.x, dims.y, dims.z)
        if 0.0 < max_extent < 0.5:
            return 0.001, "Auto Scale: Meters (1 unit = 1m)"
        return 1.0, "Auto Scale: Millimeters (1 unit = 1mm)"

    unit_settings = context.scene.unit_settings
    if unit_settings.system == 'METRIC':
        scale = unit_settings.scale_length
        return scale, f"Auto Scale: Scene ({scale:.3f})"

    return 1.0, "Auto Scale: Millimeters (1 unit = 1mm)"


def find_viewport_region_and_rv3d(context):
    if context.area is None or context.area.type != 'VIEW_3D':
        return None, None

    win_region = next((r for r in context.area.regions if r.type == 'WINDOW'), None)
    space_3d = next((s for s in context.area.spaces if s.type == 'VIEW_3D'), None)
    rv3d = space_3d.region_3d if space_3d is not None else None
    return win_region, rv3d


def assign_valid_boolean_solver(bool_mod, requested_solver):
    valid_solvers = {item.identifier for item in bool_mod.bl_rna.properties['solver'].enum_items}

    if requested_solver == 'FAST':
        for candidate in ('FLOAT', 'FAST', 'MANIFOLD', 'EXACT'):
            if candidate in valid_solvers:
                bool_mod.solver = candidate
                break
    elif requested_solver in valid_solvers:
        bool_mod.solver = requested_solver
    elif 'FLOAT' in valid_solvers:
        bool_mod.solver = 'FLOAT'
    elif 'FAST' in valid_solvers:
        bool_mod.solver = 'FAST'
    elif 'EXACT' in valid_solvers:
        bool_mod.solver = 'EXACT'

    if hasattr(bool_mod, "use_self"):
        bool_mod.use_self = False
    if hasattr(bool_mod, "use_hole_tolerant"):
        bool_mod.use_hole_tolerant = False


def compute_overshoot(unit_scale, final_depth):
    return min(0.40 * unit_scale, max(0.18 * unit_scale, final_depth * 0.14))


# =========================================================================
# CONCAVE SOCKET AUTO-CENTERING, RIM DEPTH & AXIS LOCK ENGINE
# =========================================================================
def build_tangent_basis(normal):
    up = Vector((0.0, 0.0, 1.0)) if abs(normal.z) < 0.9 else Vector((1.0, 0.0, 0.0))
    t1 = normal.cross(up).normalized()
    t2 = normal.cross(t1).normalized()
    return t1, t2


def center_on_curved_socket(target_obj, hit_world, normal_world, sample_radius, iterations=2):
    """
    Uses a multi-ray ring sample in local space to find the symmetry apex/center
    and true averaged normal of a concave socket (e.g. shoulder pad cup) or dome.
    """
    mat_world = target_obj.matrix_world
    mat_inv = mat_world.inverted_safe()
    norm_mat = mat_inv.transposed().to_3x3()

    cur_loc = hit_world.copy()
    cur_norm = normal_world.normalized()

    sample_Count = 12
    step_angle = (2.0 * math.pi) / sample_Count

    for _ in range(iterations):
        t1, t2 = build_tangent_basis(cur_norm)
        ray_lift = max(sample_radius * 1.5, 0.5)
        ray_span = ray_lift * 3.0

        accum_norm = cur_norm.copy()
        shift_u1 = 0.0
        shift_u2 = 0.0
        valid_samples = 0

        for i in range(sample_Count):
            ang = i * step_angle
            ca, sa = math.cos(ang), math.sin(ang)
            offset_dir = (t1 * ca + t2 * sa) * (sample_radius * 0.75)

            origin_world = cur_loc + offset_dir + (cur_norm * ray_lift)
            dir_world = -cur_norm

            orig_local = mat_inv @ origin_world
            dir_local = (mat_inv.to_3x3() @ dir_world).normalized()

            hit, loc_l, norm_l, _ = target_obj.ray_cast(orig_local, dir_local, distance=ray_span)
            if hit:
                s_norm = (norm_mat @ norm_l).normalized()
                if s_norm.dot(cur_norm) < 0.2:
                    continue
                accum_norm += s_norm

                # Normal convergence toward socket center:
                # On a concave cup, wall normals tilt inward toward the center;
                # On a convex dome, wall normals tilt outward away from the peak.
                n_u1 = s_norm.dot(t1)
                n_u2 = s_norm.dot(t2)
                # Radial component of normal tilt (>0 convex, <0 concave)
                radial_tilt = n_u1 * ca + n_u2 * sa
                if abs(radial_tilt) > 0.02:
                    # Project toward the point where normal aligns with cur_norm
                    shift_u1 += (-n_u1 / radial_tilt) * (sample_radius * 0.35)
                    shift_u2 += (-n_u2 / radial_tilt) * (sample_radius * 0.35)
                    valid_samples += 1

        if valid_samples >= 4:
            cur_norm = accum_norm.normalized()
            avg_u1 = max(-sample_radius * 0.65, min(sample_radius * 0.65, shift_u1 / valid_samples))
            avg_u2 = max(-sample_radius * 0.65, min(sample_radius * 0.65, shift_u2 / valid_samples))
            candidate_world = cur_loc + t1 * avg_u1 + t2 * avg_u2 + cur_norm * ray_lift

            orig_l = mat_inv @ candidate_world
            dir_l = (mat_inv.to_3x3() @ (-cur_norm)).normalized()
            hit_c, loc_c, norm_c, _ = target_obj.ray_cast(orig_l, dir_l, distance=ray_span)
            if hit_c:
                cur_loc = mat_world @ loc_c
                re_norm = (norm_mat @ norm_c).normalized()
                if re_norm.dot(cur_norm) > 0.0:
                    cur_norm = (cur_norm * 0.6 + re_norm * 0.4).normalized()

    return cur_loc, cur_norm


def compute_axis_locked_rotation(props, surface_normal, view_vector=None):
    """
    Computes the cutter's drilling axis normal and full orientation quaternion,
    applying Axis Lock (Normal / View / X / Y / Z) and custom angle tilts + spin.
    """
    mode = props.axis_mode
    base_norm = surface_normal.normalized()

    if mode == 'VIEW' and view_vector is not None:
        base_norm = (-view_vector).normalized()
    elif mode == 'X':
        sign = -1.0 if surface_normal.x < 0.0 else 1.0
        base_norm = Vector((sign, 0.0, 0.0))
    elif mode == 'Y':
        sign = -1.0 if surface_normal.y < 0.0 else 1.0
        base_norm = Vector((0.0, sign, 0.0))
    elif mode == 'Z':
        sign = -1.0 if surface_normal.z < 0.0 else 1.0
        base_norm = Vector((0.0, 0.0, sign))

    base_quat = Vector((0.0, 0.0, 1.0)).rotation_difference(base_norm)

    tilt_x_rad = math.radians(props.tilt_angle_x)
    tilt_y_rad = math.radians(props.tilt_angle_y)
    spin_z_rad = math.radians(props.spin_angle_z)

    local_euler_quat = (
        Quaternion(Vector((1.0, 0.0, 0.0)), tilt_x_rad)
        @ Quaternion(Vector((0.0, 1.0, 0.0)), tilt_y_rad)
        @ Quaternion(Vector((0.0, 0.0, 1.0)), spin_z_rad)
    )
    final_quat = base_quat @ local_euler_quat
    final_axis = (final_quat @ Vector((0.0, 0.0, 1.0))).normalized()
    return final_axis, final_quat


def adjust_for_lowest_rim_depth(target_obj, hit_world, axis_normal, radius):
    """
    On curved surfaces, samples the perimeter at `radius` so the magnet depth
    is measured from the lowest perimeter rim (preventing overhang on convex curves).
    """
    mat_world = target_obj.matrix_world
    mat_inv = mat_world.inverted_safe()
    t1, t2 = build_tangent_basis(axis_normal)

    ray_lift = max(radius * 1.5, 0.8)
    ray_span = ray_lift * 3.5

    min_height = 0.0
    max_height = 0.0
    samples = 12
    step = (2.0 * math.pi) / samples

    for i in range(samples):
        ang = i * step
        rim_offset = (t1 * math.cos(ang) + t2 * math.sin(ang)) * radius
        ray_orig_w = hit_world + rim_offset + (axis_normal * ray_lift)

        orig_l = mat_inv @ ray_orig_w
        dir_l = (mat_inv.to_3x3() @ (-axis_normal)).normalized()
        hit, loc_l, _, _ = target_obj.ray_cast(orig_l, dir_l, distance=ray_span)
        if hit:
            rim_pt_w = mat_world @ loc_l
            rel_h = (rim_pt_w - hit_world).dot(axis_normal)
            if rel_h < min_height:
                min_height = rel_h
            if rel_h > max_height:
                max_height = rel_h

    # Shift the surface reference down to min_height (if negative on a convex dome)
    adjusted_hit = hit_world + (axis_normal * min_height)
    extra_overshoot = max(0.0, max_height - min_height)
    return adjusted_hit, extra_overshoot


# =========================================================================
# MULTI-SHAPE BMESH GENERATOR (CYLINDER, SPHERE, RING/PLUG, BAR)
# =========================================================================
def _finalize_bmesh_normals_and_smoothing(bm, mesh_data):
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.normal_update()

    for face in bm.faces:
        is_cap = abs(face.normal.z) > 0.85
        face.smooth = not is_cap

    for edge in bm.edges:
        if len(edge.link_faces) == 2:
            f0_cap = abs(edge.link_faces[0].normal.z) > 0.85
            f1_cap = abs(edge.link_faces[1].normal.z) > 0.85
            edge.smooth = not (f0_cap != f1_cap)
        else:
            edge.smooth = False

    bm.to_mesh(mesh_data)
    bm.free()
    mesh_data.materials.clear()
    mesh_data.update()


def _build_revolved_solid_bmesh(bm, profile_rz, segments):
    """
    Revolves a (radius, z) profile list (ordered from bottom to top, radius > 0)
    into a closed manifold solid with single N-gon bottom and top caps (no center poles).
    """
    step = (2.0 * math.pi) / segments
    rings = []

    for r, z in profile_rz:
        ring_verts = [
            bm.verts.new((math.cos(i * step) * r, math.sin(i * step) * r, z))
            for i in range(segments)
        ]
        rings.append(ring_verts)

    # Bottom cap (clockwise looking from +Z so normal points -Z)
    bm.faces.new(list(reversed(rings[0])))

    # Side quad strips
    for r_idx in range(len(rings) - 1):
        low_ring = rings[r_idx]
        high_ring = rings[r_idx + 1]
        for i in range(segments):
            nxt = (i + 1) % segments
            bm.faces.new((low_ring[i], low_ring[nxt], high_ring[nxt], high_ring[i]))

    # Top cap (counter-clockwise so normal points +Z)
    bm.faces.new(rings[-1])


def _build_annular_tube_bmesh(bm, outer_rz, inner_rz, segments):
    """
    Builds a watertight manifold hollow ring cylinder (donut trench) between outer_rz and inner_rz.
    """
    step = (2.0 * math.pi) / segments
    outer_rings = []
    inner_rings = []

    for r, z in outer_rz:
        outer_rings.append([
            bm.verts.new((math.cos(i * step) * r, math.sin(i * step) * r, z))
            for i in range(segments)
        ])

    for r, z in inner_rz:
        inner_rings.append([
            bm.verts.new((math.cos(i * step) * r, math.sin(i * step) * r, z))
            for i in range(segments)
        ])

    # Outer wall quads
    for r_idx in range(len(outer_rings) - 1):
        low_r = outer_rings[r_idx]
        high_r = outer_rings[r_idx + 1]
        for i in range(segments):
            nxt = (i + 1) % segments
            bm.faces.new((low_r[i], low_r[nxt], high_r[nxt], high_r[i]))

    # Inner wall quads (normals facing inward toward center post)
    for r_idx in range(len(inner_rings) - 1):
        low_r = inner_rings[r_idx]
        high_r = inner_rings[r_idx + 1]
        for i in range(segments):
            nxt = (i + 1) % segments
            bm.faces.new((low_r[nxt], low_r[i], high_r[i], high_r[nxt]))

    # Bottom annular ring quads + Top annular ring quads
    bot_out = outer_rings[0]
    bot_in = inner_rings[0]
    top_out = outer_rings[-1]
    top_in = inner_rings[-1]

    for i in range(segments):
        nxt = (i + 1) % segments
        bm.faces.new((bot_out[nxt], bot_out[i], bot_in[i], bot_in[nxt]))
        bm.faces.new((top_out[i], top_out[nxt], top_in[nxt], top_in[i]))


def build_peg_bmesh_into_data(
    mesh_data,
    inner_radius,
    depth,
    overshoot,
    segments,
    chamfer,
    counterpart_depth=None,
):
    """
    Constructs the manifold BMesh for the protruding alignment peg in RING PLUG mode.
    Anchors into the solid core beneath the relief cut floor and protrudes outward
    past the surface by `counterpart_depth` (the thickness of the mating counterpart magnet),
    with a lead-in chamfer at the top tip.
    Total column height = depth + counterpart_depth.
    """
    bm = bmesh.new()
    if counterpart_depth is None or counterpart_depth <= 0.0:
        cp_depth = depth
    else:
        cp_depth = counterpart_depth

    total_height = depth + overshoot
    z_bot = -total_height * 0.5
    z_surf = (depth - overshoot) * 0.5
    z_anchor = z_bot - max(depth * 0.08, 0.05)
    z_peg_top = z_surf + cp_depth
    peg_r = max(0.15, inner_radius)

    chamfer_peg = min(peg_r * 0.22, cp_depth * 0.2, 0.3) if chamfer > 0.001 else min(peg_r * 0.15, 0.2)

    profile_rz = [(peg_r, z_anchor)]
    if chamfer_peg > 0.02 and (z_peg_top - chamfer_peg) > z_anchor + 0.05:
        profile_rz.append((peg_r, z_peg_top - chamfer_peg))
        profile_rz.append((max(0.05, peg_r - chamfer_peg), z_peg_top))
    else:
        profile_rz.append((peg_r, z_peg_top))

    _build_revolved_solid_bmesh(bm, profile_rz, segments)
    _finalize_bmesh_normals_and_smoothing(bm, mesh_data)


def build_cutter_bmesh_into_data(
    mesh_data,
    shape_type,
    ring_mode,
    radius,
    inner_radius,
    bar_length,
    depth,
    overshoot,
    segments,
    chamfer,
    use_glue_relief,
    ball_radius=1.5,
    cup_depth=1.0,
    magnet_depth=2.0,
):
    """
    Constructs the manifold BMesh for CYLINDER, SPHERE (with Auto-Sleeve),
    BALL_SOCKET (Dome Cup + Magnet Hole at bottom), RING (Donut/Full/Plug),
    or BAR, including optional 45° entry chamfer and bottom glue relief dimple.
    """
    bm = bmesh.new()
    total_height = depth + overshoot
    z_bot = -total_height * 0.5
    z_top = total_height * 0.5
    z_surf = (depth - overshoot) * 0.5

    if shape_type == 'BALL_SOCKET':
        # Composite: Cylindrical magnet hole from z_bot to z_apex, then spherical cup up to z_surf
        z_apex = z_surf - cup_depth
        z_center = z_apex + ball_radius
        r_mag = radius

        # Transition height where sphere widens past magnet radius
        if ball_radius > r_mag:
            dz_trans = -math.sqrt(ball_radius * ball_radius - r_mag * r_mag)
            z_trans = max(z_bot, z_center + dz_trans)
        else:
            z_trans = z_apex

        profile_rz = []

        # Optional bottom glue relief dimple in the magnet cylinder floor
        if use_glue_relief and magnet_depth > 0.4:
            relief_d = min(magnet_depth * 0.22, 0.35)
            profile_rz.append((r_mag * 0.40, z_bot - relief_d))
            profile_rz.append((r_mag * 0.50, z_bot))

        profile_rz.append((r_mag, z_bot))

        # Vertical cylindrical shaft up to z_trans
        if z_trans > z_bot + 0.05:
            profile_rz.append((r_mag, z_trans))

        # Spherical cup arc from z_trans up to z_surf
        cup_steps = max(8, segments // 3)
        z_start_arc = max(z_trans, z_apex)
        for s in range(1, cup_steps + 1):
            zz = z_start_arc + (s / cup_steps) * (z_surf - z_start_arc)
            dz = zz - z_center
            if dz < 0.0:
                rr = math.sqrt(max(0.01, ball_radius * ball_radius - dz * dz))
            else:
                rr = ball_radius  # Auto-sleeve: no undercut trap
            profile_rz.append((max(r_mag, rr), zz))

        # Entry chamfer or straight overshoot
        r_surf = profile_rz[-1][0]
        if chamfer > 0.001 and (z_surf - chamfer) > z_start_arc:
            profile_rz.append((r_surf + chamfer, z_surf))
            profile_rz.append((r_surf + chamfer, z_top))
        else:
            profile_rz.append((r_surf, z_top))

        _build_revolved_solid_bmesh(bm, profile_rz, segments)
        _finalize_bmesh_normals_and_smoothing(bm, mesh_data)
        return

    if shape_type == 'BAR':
        hx = radius
        hy = bar_length * 0.5
        profile = []
        if use_glue_relief and depth > 0.4:
            relief_d = min(depth * 0.22, 0.35)
            profile.append((hx * 0.42, hy * 0.42, z_bot - relief_d))
            profile.append((hx * 0.52, hy * 0.52, z_bot))
        profile.append((hx, hy, z_bot))

        if chamfer > 0.001 and (z_surf - chamfer) > z_bot + 0.05:
            profile.append((hx, hy, z_surf - chamfer))
            profile.append((hx + chamfer, hy + chamfer, z_surf))
            profile.append((hx + chamfer, hy + chamfer, z_top))
        else:
            profile.append((hx, hy, z_top))

        rings = []
        for rx, ry, zz in profile:
            rings.append([
                bm.verts.new((-rx, -ry, zz)),
                bm.verts.new((rx, -ry, zz)),
                bm.verts.new((rx, ry, zz)),
                bm.verts.new((-rx, ry, zz)),
            ])
        bm.faces.new(reversed(rings[0]))
        for r_idx in range(len(rings) - 1):
            l_r = rings[r_idx]
            h_r = rings[r_idx + 1]
            for i in range(4):
                nxt = (i + 1) % 4
                bm.faces.new((l_r[i], l_r[nxt], h_r[nxt], h_r[i]))
        bm.faces.new(rings[-1])
        _finalize_bmesh_normals_and_smoothing(bm, mesh_data)
        return

    if shape_type == 'SPHERE':
        # Auto-Sleeve Sphere: hemispherical bottom + cylindrical entry shaft if depth > radius
        z_center = z_bot + radius
        lat_rings = max(10, segments // 3)
        profile_rz = []

        for i in range(1, lat_rings + 1):
            # theta from 0 (bottom pole) to pi/2 (equator)
            theta = (i / lat_rings) * (math.pi * 0.5)
            zz = z_center - math.cos(theta) * radius
            rr = math.sin(theta) * radius
            if zz >= z_top:
                break
            profile_rz.append((max(0.02, rr), zz))

        if z_center < z_top:
            if chamfer > 0.001 and (z_surf - chamfer) > z_center:
                profile_rz.append((radius, z_surf - chamfer))
                profile_rz.append((radius + chamfer, z_surf))
                profile_rz.append((radius + chamfer, z_top))
            else:
                profile_rz.append((radius, z_top))
        else:
            # Shallow spherical dimple where equator is above z_top
            theta_top = math.acos(max(-1.0, min(1.0, (z_center - z_top) / radius)))
            r_top = max(0.05, math.sin(theta_top) * radius)
            profile_rz.append((r_top, z_top))

        _build_revolved_solid_bmesh(bm, profile_rz, segments)
        _finalize_bmesh_normals_and_smoothing(bm, mesh_data)
        return

    if shape_type == 'RING':
        eff_in = max(0.15, min(inner_radius, radius - 0.15))
        if ring_mode == 'DONUT':
            outer_rz = [(radius, z_bot)]
            if chamfer > 0.001 and (z_surf - chamfer) > z_bot + 0.05:
                outer_rz.append((radius, z_surf - chamfer))
                outer_rz.append((radius + chamfer, z_surf))
                outer_rz.append((radius + chamfer, z_top))
            else:
                outer_rz.append((radius, z_top))

            inner_rz = [(eff_in, z_bot), (eff_in, z_top)]
            _build_annular_tube_bmesh(bm, outer_rz, inner_rz, segments)
            _finalize_bmesh_normals_and_smoothing(bm, mesh_data)
            return
        # If ring_mode in {'FULL', 'PLUG'}, fall through to full circular relief pocket

    # Standard CYLINDER (or RING in FULL / PLUG mode)
    profile_rz = []
    if use_glue_relief and depth > 0.4 and shape_type != 'RING':
        relief_d = min(depth * 0.22, 0.35)
        profile_rz.append((radius * 0.40, z_bot - relief_d))
        profile_rz.append((radius * 0.50, z_bot))

    profile_rz.append((radius, z_bot))
    if chamfer > 0.001 and (z_surf - chamfer) > z_bot + 0.05:
        profile_rz.append((radius, z_surf - chamfer))
        profile_rz.append((radius + chamfer, z_surf))
        profile_rz.append((radius + chamfer, z_top))
    else:
        profile_rz.append((radius, z_top))

    _build_revolved_solid_bmesh(bm, profile_rz, segments)
    _finalize_bmesh_normals_and_smoothing(bm, mesh_data)


def apply_cutter_visual_style(cutter_obj, display_mode):
    cutter_obj.color = (0.05, 0.07, 0.10, 0.38)
    cutter_obj.hide_render = True

    if display_mode == 'SHADOW':
        cutter_obj.display_type = 'WIRE'
        cutter_obj.show_wire = False
        cutter_obj.show_in_front = False
    elif display_mode == 'FACETS':
        cutter_obj.display_type = 'SOLID'
        cutter_obj.show_wire = True
        cutter_obj.show_in_front = False
    else:
        cutter_obj.display_type = 'WIRE'
        cutter_obj.show_wire = True
        cutter_obj.show_in_front = True


def raycast_scene_models(context, ray_origin_world, view_vector_world, exclude_obj=None):
    best_hit_obj = None
    best_hit_loc = None
    best_hit_normal = None
    best_dist_sq = float('inf')

    ray_dir_world = view_vector_world.normalized()

    for obj in context.visible_objects:
        if obj.type != 'MESH' or obj.get(TAG_IS_CUTTER, False) or obj == exclude_obj:
            continue

        mat_world = obj.matrix_world
        mat_inv = mat_world.inverted_safe()
        local_orig = mat_inv @ ray_origin_world
        local_dir = (mat_inv.to_3x3() @ ray_dir_world).normalized()

        hit, loc_local, norm_local, _ = obj.ray_cast(local_orig, local_dir)
        if hit:
            world_loc = mat_world @ loc_local
            dist_sq = (world_loc - ray_origin_world).length_squared
            if dist_sq < best_dist_sq:
                best_dist_sq = dist_sq
                best_hit_obj = obj
                best_hit_loc = world_loc
                world_norm = (mat_inv.transposed().to_3x3() @ norm_local).normalized()
                if world_norm.dot(ray_dir_world) > 0.0:
                    world_norm = -world_norm
                best_hit_normal = world_norm

    return best_hit_obj, best_hit_loc, best_hit_normal


def compute_cutter_parameters_from_props(context, target_obj):
    props = context.scene.magnet_props
    unit_scale, _ = resolve_unit_scale(context, target_obj)

    final_diameter = (props.magnet_diameter + props.dia_clearance) * unit_scale
    final_depth = (props.magnet_depth + props.depth_clearance) * unit_scale
    radius = final_diameter * 0.5

    # For Ring magnets: Outer expands (+clearance) and Inner shrinks (-clearance)
    raw_inner_dia = max(0.3, props.inner_diameter - props.dia_clearance)
    inner_radius = (raw_inner_dia * unit_scale) * 0.5

    # For Ball Socket (Spherical Cup + Cylindrical Magnet Hole at dome bottom)
    ball_dia = (props.ball_diameter + props.dia_clearance) * unit_scale
    cup_depth = (props.cup_depth + props.depth_clearance * 0.5) * unit_scale
    ball_radius = ball_dia * 0.5

    bar_length = (props.bar_length + props.dia_clearance) * unit_scale
    chamfer = (props.chamfer_size * unit_scale) if props.use_entry_chamfer else 0.0

    if props.shape_type == 'BALL_SOCKET':
        total_depth = cup_depth + final_depth
        dz_surf = max(0.0, ball_radius - cup_depth)
        surf_radius = math.sqrt(max(0.01, ball_radius * ball_radius - dz_surf * dz_surf))
    else:
        total_depth = final_depth
        surf_radius = radius

    overshoot = compute_overshoot(unit_scale, total_depth)
    counterpart_depth = (props.counterpart_magnet_depth + props.depth_clearance) * unit_scale

    return {
        "unit_scale": unit_scale,
        "shape_type": props.shape_type,
        "ring_mode": props.ring_mode,
        "radius": radius,
        "inner_radius": inner_radius,
        "ball_radius": ball_radius,
        "ball_diameter_mm": props.ball_diameter,
        "cup_depth": cup_depth,
        "magnet_depth": final_depth,
        "surf_radius": surf_radius,
        "bar_length": bar_length,
        "depth": total_depth,
        "counterpart_depth": counterpart_depth,
        "counterpart_mag_depth_mm": props.counterpart_magnet_depth,
        "overshoot": overshoot,
        "segments": props.segments,
        "chamfer": chamfer,
        "glue_relief": props.use_glue_relief,
    }


def compute_cutter_world_matrix(target_obj, raw_hit_loc, raw_hit_normal, params, props, view_vector=None):
    hit_loc = raw_hit_loc.copy()
    surf_norm = raw_hit_normal.normalized()
    sample_r = params.get("surf_radius", params["radius"])

    if props.auto_center_concave and target_obj is not None:
        hit_loc, surf_norm = center_on_curved_socket(
            target_obj, hit_loc, surf_norm, sample_r
        )

    axis_normal, rot_quat = compute_axis_locked_rotation(props, surf_norm, view_vector)

    extra_overshoot = 0.0
    if props.depth_reference == 'LOWEST_RIM' and target_obj is not None:
        hit_loc, extra_overshoot = adjust_for_lowest_rim_depth(
            target_obj, hit_loc, axis_normal, sample_r
        )

    eff_overshoot = params["overshoot"] + extra_overshoot
    depth = params["depth"]

    # All cutters extend -depth inward along axis_normal and +eff_overshoot outward
    center = hit_loc - (axis_normal * ((depth - eff_overshoot) * 0.5))

    mat = Matrix.LocRotScale(center, rot_quat, Vector((1.0, 1.0, 1.0)))
    return mat, hit_loc, surf_norm, axis_normal, eff_overshoot


def create_cutter_cylinder_data_api(context, target_obj, hit_loc, hit_normal, view_vector=None):
    cleanup_orphan_modifiers_and_collections()

    props = context.scene.magnet_props
    params = compute_cutter_parameters_from_props(context, target_obj)
    mat_world, final_hit_loc, final_surf_norm, axis_norm, eff_overshoot = compute_cutter_world_matrix(
        target_obj, hit_loc, hit_normal, params, props, view_vector
    )

    if props.shape_type == 'BALL_SOCKET':
        cutter_name = f"Magnet_BallSocket_{props.ball_diameter:.1f}mm_Cup{props.cup_depth:.1f}mm_Mag{props.magnet_diameter:.1f}x{props.magnet_depth:.1f}mm"
    elif props.shape_type == 'RING':
        cutter_name = f"Magnet_Ring_{props.ring_mode.title()}_{props.magnet_diameter:.1f}x{props.magnet_depth:.1f}mm"
    else:
        shape_label = props.shape_type.title()
        cutter_name = f"Magnet_{shape_label}_{props.magnet_diameter:.1f}x{props.magnet_depth:.1f}mm"

    mesh_data = bpy.data.meshes.new(name=cutter_name)
    build_cutter_bmesh_into_data(
        mesh_data,
        params["shape_type"],
        params["ring_mode"],
        params["radius"],
        params["inner_radius"],
        params["bar_length"],
        params["depth"],
        eff_overshoot,
        params["segments"],
        params["chamfer"],
        params["glue_relief"],
        ball_radius=params.get("ball_radius", 1.5),
        cup_depth=params.get("cup_depth", 1.0),
        magnet_depth=params.get("magnet_depth", params["depth"]),
    )

    cutter_obj = bpy.data.objects.new(name=cutter_name, object_data=mesh_data)
    cutter_obj.matrix_world = mat_world

    cutter_col = get_or_create_cutter_collection(context)
    cutter_col.objects.link(cutter_obj)

    apply_cutter_visual_style(cutter_obj, props.display_mode)

    is_plug = (params["shape_type"] == 'RING' and params["ring_mode"] == 'PLUG')
    trench_mod_name = f"{MODIFIER_PREFIX}_Trench" if is_plug else MODIFIER_PREFIX
    bool_mod = target_obj.modifiers.new(name=trench_mod_name, type='BOOLEAN')
    bool_mod.operation = 'DIFFERENCE'
    bool_mod.object = cutter_obj
    assign_valid_boolean_solver(bool_mod, props.boolean_solver)
    bool_mod.show_viewport = props.live_boolean_preview

    if is_plug:
        peg_mesh = bpy.data.meshes.new(name=f"{cutter_name}_Peg")
        build_peg_bmesh_into_data(
            peg_mesh,
            params["inner_radius"],
            params["depth"],
            eff_overshoot,
            params["segments"],
            params["chamfer"],
            counterpart_depth=params.get("counterpart_depth", params["depth"]),
        )
        peg_obj = bpy.data.objects.new(name=f"{cutter_obj.name}_Peg", object_data=peg_mesh)
        peg_obj.matrix_world = cutter_obj.matrix_world.copy()
        peg_obj.parent = cutter_obj
        peg_obj.matrix_parent_inverse = cutter_obj.matrix_world.inverted()
        peg_obj.matrix_local = Matrix.Identity(4)
        cutter_col.objects.link(peg_obj)
        apply_cutter_visual_style(peg_obj, props.display_mode)
        peg_obj.hide_select = False
        peg_obj[TAG_IS_CUTTER] = True
        peg_obj[TAG_IS_PEG] = True
        peg_obj[TAG_PARENT_CUTTER] = cutter_obj.name
        peg_obj[TAG_TARGET_NAME] = target_obj.name

        bool_mod_peg = target_obj.modifiers.new(name=f"{MODIFIER_PREFIX}_Peg", type='BOOLEAN')
        bool_mod_peg.operation = 'UNION'
        bool_mod_peg.object = peg_obj
        assign_valid_boolean_solver(bool_mod_peg, props.boolean_solver)
        bool_mod_peg.show_viewport = props.live_boolean_preview
        peg_obj[TAG_MODIFIER_NAME] = bool_mod_peg.name
        cutter_obj[TAG_PEG_OBJ] = peg_obj.name
    else:
        cutter_obj[TAG_PEG_OBJ] = ""

    cutter_obj[TAG_IS_CUTTER] = True
    cutter_obj[TAG_TARGET_NAME] = target_obj.name
    cutter_obj[TAG_MODIFIER_NAME] = bool_mod.name
    cutter_obj[TAG_SHAPE] = params["shape_type"]
    cutter_obj[TAG_RING_MODE] = params["ring_mode"]
    cutter_obj[TAG_RADIUS] = params["radius"]
    cutter_obj[TAG_INNER_RADIUS] = params["inner_radius"]
    cutter_obj[TAG_BALL_DIAMETER] = params.get("ball_diameter_mm", props.ball_diameter)
    cutter_obj[TAG_BALL_RADIUS] = params.get("ball_radius", params["radius"])
    cutter_obj[TAG_CUP_DEPTH] = params.get("cup_depth", 0.0)
    cutter_obj[TAG_MAGNET_DEPTH] = params.get("magnet_depth", params["depth"])
    cutter_obj["ball_dia_mm"] = float(props.ball_diameter if props.shape_type == 'BALL_SOCKET' else props.magnet_diameter)
    cutter_obj["plunge_depth_mm"] = float(props.magnet_depth)
    cutter_obj["cup_depth_mm"] = float(props.cup_depth)
    cutter_obj["magnet_dia_mm"] = float(props.magnet_diameter)
    cutter_obj["magnet_depth_mm"] = float(props.magnet_depth)
    cutter_obj[TAG_BAR_LENGTH] = params["bar_length"]
    cutter_obj[TAG_DEPTH] = params["depth"]
    cutter_obj[TAG_COUNTERPART_DEPTH] = params.get("counterpart_depth", params["depth"])
    cutter_obj["counterpart_mag_depth_mm"] = float(params.get("counterpart_mag_depth_mm", props.counterpart_magnet_depth))
    cutter_obj[TAG_OVERSHOOT] = eff_overshoot
    cutter_obj[TAG_SEGMENTS] = params["segments"]
    cutter_obj[TAG_CHAMFER] = params["chamfer"]
    cutter_obj[TAG_GLUE_RELIEF] = bool(params["glue_relief"])
    cutter_obj[TAG_HIT_LOC] = (final_hit_loc.x, final_hit_loc.y, final_hit_loc.z)
    cutter_obj[TAG_HIT_NORMAL] = (final_surf_norm.x, final_surf_norm.y, final_surf_norm.z)
    cutter_obj[TAG_AXIS_NORMAL] = (axis_norm.x, axis_norm.y, axis_norm.z)

    for selected in context.selected_objects:
        selected.select_set(False)
    cutter_obj.select_set(True)
    context.view_layer.objects.active = cutter_obj

    CutterOverlay3D.enable()
    return cutter_obj


# =========================================================================
# LIVE PROPERTY UPDATE CALLBACKS
# =========================================================================
_suppress_cutter_refresh = False


def get_selected_cutters(context):
    raw_objs = [
        o for o in getattr(context, "selected_objects", [])
        if (o.get(TAG_IS_CUTTER, False) or o.get(TAG_IS_PEG, False)) and o.type == 'MESH'
    ]
    active = getattr(context, "active_object", None)
    if active is not None and (active.get(TAG_IS_CUTTER, False) or active.get(TAG_IS_PEG, False)) and active.type == 'MESH':
        if active not in raw_objs:
            raw_objs.append(active)

    cutters = []
    for o in raw_objs:
        parent_name = o.get(TAG_PARENT_CUTTER, "")
        if parent_name and parent_name in bpy.data.objects:
            p_obj = bpy.data.objects[parent_name]
            if p_obj not in cutters:
                cutters.append(p_obj)
        elif o.parent is not None and o.parent.get(TAG_IS_CUTTER, False):
            if o.parent not in cutters:
                cutters.append(o.parent)
        else:
            if o not in cutters:
                cutters.append(o)
    return cutters


def resolve_target_mesh_object(context):
    active = getattr(context, "active_object", None)
    if active is not None:
        if active.type == 'MESH' and not active.get(TAG_IS_CUTTER, False):
            return active
        if active.get(TAG_IS_CUTTER, False):
            linked_target = bpy.data.objects.get(active.get(TAG_TARGET_NAME, ""))
            if linked_target is not None and linked_target.type == 'MESH':
                return linked_target

    for obj in getattr(context, "selected_objects", []):
        if obj.type == 'MESH' and not obj.get(TAG_IS_CUTTER, False):
            return obj
        if obj.get(TAG_IS_CUTTER, False):
            linked_target = bpy.data.objects.get(obj.get(TAG_TARGET_NAME, ""))
            if linked_target is not None and linked_target.type == 'MESH':
                return linked_target

    return None


def refresh_selected_cutter_geometry(context):
    global _suppress_cutter_refresh
    if _suppress_cutter_refresh:
        return

    props = context.scene.magnet_props
    cutters = get_selected_cutters(context)
    if not cutters:
        return

    for cutter in cutters:
        parent_name = cutter.get(TAG_PARENT_CUTTER, "")
        if parent_name:
            parent_obj = bpy.data.objects.get(parent_name)
            if parent_obj is not None:
                cutter = parent_obj

        target_name = cutter.get(TAG_TARGET_NAME, "")
        target_obj = bpy.data.objects.get(target_name) if target_name else None
        if target_obj is None:
            target_obj = resolve_target_mesh_object(context)
            if target_obj is not None:
                cutter[TAG_TARGET_NAME] = target_obj.name

        params = compute_cutter_parameters_from_props(context, target_obj)

        hit_loc_tuple = cutter.get(TAG_HIT_LOC, None)
        hit_norm_tuple = cutter.get(TAG_HIT_NORMAL, None)
        old_depth = float(cutter.get(TAG_DEPTH, params["depth"]))
        old_over = float(cutter.get(TAG_OVERSHOOT, params["overshoot"]))
        current_norm = (cutter.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()
        current_loc = cutter.matrix_world.translation + (current_norm * ((old_depth - old_over) * 0.5))

        if hit_loc_tuple is not None and hit_norm_tuple is not None:
            axis_n = Vector(cutter.get(TAG_AXIS_NORMAL, hit_norm_tuple)).normalized()
            expected_center = Vector(hit_loc_tuple) - (axis_n * ((old_depth - old_over) * 0.5))
            if (cutter.matrix_world.translation - expected_center).length > 1e-4:
                raw_loc = current_loc
                raw_norm = current_norm
            else:
                raw_loc = Vector(hit_loc_tuple)
                raw_norm = Vector(hit_norm_tuple).normalized()
        else:
            raw_loc = current_loc
            raw_norm = current_norm

        mat_world, final_loc, final_norm, axis_norm, eff_overshoot = compute_cutter_world_matrix(
            target_obj, raw_loc, raw_norm, params, props
        )

        build_cutter_bmesh_into_data(
            cutter.data,
            params["shape_type"],
            params["ring_mode"],
            params["radius"],
            params["inner_radius"],
            params["bar_length"],
            params["depth"],
            eff_overshoot,
            params["segments"],
            params["chamfer"],
            params["glue_relief"],
            ball_radius=params.get("ball_radius", 1.5),
            cup_depth=params.get("cup_depth", 1.0),
            magnet_depth=params.get("magnet_depth", params["depth"]),
        )
        apply_cutter_visual_style(cutter, props.display_mode)
        cutter.matrix_world = mat_world

        is_plug = (params["shape_type"] == 'RING' and params["ring_mode"] == 'PLUG')

        if target_obj is not None:
            mod = target_obj.modifiers.get(cutter.get(TAG_MODIFIER_NAME, ""))
            if mod is not None and mod.type == 'BOOLEAN':
                mod.operation = 'DIFFERENCE'
                mod.object = cutter
                assign_valid_boolean_solver(mod, props.boolean_solver)
                mod.show_viewport = props.live_boolean_preview
            else:
                for m in target_obj.modifiers:
                    if m.type == 'BOOLEAN' and m.object == cutter:
                        mod = m
                        break
                if mod is None:
                    trench_name = f"{MODIFIER_PREFIX}_Trench" if is_plug else MODIFIER_PREFIX
                    mod = target_obj.modifiers.new(name=trench_name, type='BOOLEAN')
                    mod.operation = 'DIFFERENCE'
                    mod.object = cutter
                assign_valid_boolean_solver(mod, props.boolean_solver)
                mod.show_viewport = props.live_boolean_preview
                cutter[TAG_MODIFIER_NAME] = mod.name

        existing_pegs = find_associated_pegs(cutter)
        peg_obj = existing_pegs[0] if existing_pegs else None

        if is_plug:
            cutter_col = get_or_create_cutter_collection(context)
            if peg_obj is None:
                peg_mesh = bpy.data.meshes.new(name=f"{cutter.name}_Peg")
                peg_obj = bpy.data.objects.new(name=f"{cutter.name}_Peg", object_data=peg_mesh)
                peg_obj.matrix_world = cutter.matrix_world.copy()
                peg_obj.parent = cutter
                peg_obj.matrix_parent_inverse = cutter.matrix_world.inverted()
                peg_obj.matrix_local = Matrix.Identity(4)
                cutter_col.objects.link(peg_obj)
                apply_cutter_visual_style(peg_obj, props.display_mode)
                peg_obj.hide_select = False
                peg_obj[TAG_IS_CUTTER] = True
                peg_obj[TAG_IS_PEG] = True
                peg_obj[TAG_PARENT_CUTTER] = cutter.name
                peg_obj[TAG_TARGET_NAME] = target_obj.name if target_obj else ""
                cutter[TAG_PEG_OBJ] = peg_obj.name
            else:
                peg_obj.matrix_world = cutter.matrix_world.copy()
                peg_obj.parent = cutter
                peg_obj.matrix_parent_inverse = cutter.matrix_world.inverted()
                peg_obj.matrix_local = Matrix.Identity(4)
                peg_obj.hide_select = False

            build_peg_bmesh_into_data(
                peg_obj.data,
                params["inner_radius"],
                params["depth"],
                eff_overshoot,
                params["segments"],
                params["chamfer"],
                counterpart_depth=params.get("counterpart_depth", params["depth"]),
            )
            apply_cutter_visual_style(peg_obj, props.display_mode)

            if target_obj is not None:
                peg_mod_name = peg_obj.get(TAG_MODIFIER_NAME, "")
                peg_mod = target_obj.modifiers.get(peg_mod_name) if peg_mod_name else None
                if peg_mod is None:
                    peg_mod = target_obj.modifiers.new(name=f"{MODIFIER_PREFIX}_Peg", type='BOOLEAN')
                    peg_obj[TAG_MODIFIER_NAME] = peg_mod.name
                peg_mod.operation = 'UNION'
                peg_mod.object = peg_obj
                assign_valid_boolean_solver(peg_mod, props.boolean_solver)
                peg_mod.show_viewport = props.live_boolean_preview
        else:
            for p in existing_pegs:
                if target_obj is not None:
                    p_mod_name = p.get(TAG_MODIFIER_NAME, "")
                    if p_mod_name and p_mod_name in target_obj.modifiers:
                        target_obj.modifiers.remove(target_obj.modifiers[p_mod_name])
                    for m in list(target_obj.modifiers):
                        if m.type == 'BOOLEAN' and m.object == p:
                            target_obj.modifiers.remove(m)
                p_mesh = p.data
                bpy.data.objects.remove(p, do_unlink=True)
                if p_mesh is not None and p_mesh.users == 0:
                    bpy.data.meshes.remove(p_mesh)
            cutter[TAG_PEG_OBJ] = ""

        cutter[TAG_SHAPE] = params["shape_type"]
        cutter[TAG_RING_MODE] = params["ring_mode"]
        cutter[TAG_RADIUS] = params["radius"]
        cutter[TAG_INNER_RADIUS] = params["inner_radius"]
        cutter[TAG_BALL_DIAMETER] = params.get("ball_diameter_mm", props.ball_diameter)
        cutter[TAG_BALL_RADIUS] = params.get("ball_radius", params["radius"])
        cutter[TAG_CUP_DEPTH] = params.get("cup_depth", 0.0)
        cutter[TAG_MAGNET_DEPTH] = params.get("magnet_depth", params["depth"])
        cutter["ball_dia_mm"] = float(props.ball_diameter if props.shape_type == 'BALL_SOCKET' else props.magnet_diameter)
        cutter["plunge_depth_mm"] = float(props.magnet_depth)
        cutter["cup_depth_mm"] = float(props.cup_depth)
        cutter["magnet_dia_mm"] = float(props.magnet_diameter)
        cutter["magnet_depth_mm"] = float(props.magnet_depth)
        cutter[TAG_BAR_LENGTH] = params["bar_length"]
        cutter[TAG_DEPTH] = params["depth"]
        cutter[TAG_COUNTERPART_DEPTH] = params.get("counterpart_depth", params["depth"])
        cutter["counterpart_mag_depth_mm"] = float(params.get("counterpart_mag_depth_mm", props.counterpart_magnet_depth))
        cutter[TAG_OVERSHOOT] = eff_overshoot
        cutter[TAG_SEGMENTS] = params["segments"]
        cutter[TAG_CHAMFER] = params["chamfer"]
        cutter[TAG_GLUE_RELIEF] = bool(params["glue_relief"])
        cutter[TAG_HIT_LOC] = (final_loc.x, final_loc.y, final_loc.z)
        cutter[TAG_HIT_NORMAL] = (final_norm.x, final_norm.y, final_norm.z)
        cutter[TAG_AXIS_NORMAL] = (axis_norm.x, axis_norm.y, axis_norm.z)

        cutter.update_tag()
        if target_obj is not None and props.live_boolean_preview:
            target_obj.update_tag()

    CutterOverlay3D.invalidate_cache()
    if context.area is not None:
        context.area.tag_redraw()


def update_preset(self, context):
    global _suppress_cutter_refresh
    if _suppress_cutter_refresh:
        return
    dims = PRESET_DIMENSIONS.get(self.magnet_preset)
    if dims is not None:
        self.magnet_diameter, self.magnet_depth = dims
        if self.inner_diameter >= self.magnet_diameter:
            self.inner_diameter = max(0.5, self.magnet_diameter * 0.45)
        self.counterpart_magnet_depth = self.magnet_depth
    refresh_selected_cutter_geometry(context)


def update_dimensions_or_facets(self, context):
    global _suppress_cutter_refresh
    if _suppress_cutter_refresh:
        return
    refresh_selected_cutter_geometry(context)


def update_display_style(self, context):
    global _suppress_cutter_refresh
    if _suppress_cutter_refresh:
        return
    col = bpy.data.collections.get(COLLECTION_NAME)
    if col is not None:
        for cutter in col.objects:
            if cutter.get(TAG_IS_CUTTER, False) and cutter.type == 'MESH':
                apply_cutter_visual_style(cutter, self.display_mode)
    if context.area is not None:
        context.area.tag_redraw()


def update_ring_visibility(self, context):
    if context.area is not None:
        context.area.tag_redraw()


def update_live_preview(self, context):
    col = bpy.data.collections.get(COLLECTION_NAME)
    if col is not None:
        for cutter in col.objects:
            if cutter.get(TAG_IS_CUTTER, False):
                target_obj = bpy.data.objects.get(cutter.get(TAG_TARGET_NAME, ""))
                mod_name = cutter.get(TAG_MODIFIER_NAME, "")
                if target_obj is not None:
                    mod = target_obj.modifiers.get(mod_name)
                    if mod is not None and mod.type == 'BOOLEAN':
                        mod.show_viewport = self.live_boolean_preview
                        target_obj.update_tag()
    if context.area is not None:
        context.area.tag_redraw()


def update_solver_setting(self, context):
    col = bpy.data.collections.get(COLLECTION_NAME)
    if col is None:
        return
    for cutter in col.objects:
        if cutter.get(TAG_IS_CUTTER, False):
            target_obj = bpy.data.objects.get(cutter.get(TAG_TARGET_NAME, ""))
            mod_name = cutter.get(TAG_MODIFIER_NAME, "")
            if target_obj is not None:
                mod = target_obj.modifiers.get(mod_name)
                if mod is not None and mod.type == 'BOOLEAN':
                    assign_valid_boolean_solver(mod, self.boolean_solver)
                    if self.live_boolean_preview:
                        target_obj.update_tag()


def handle_modal_axis_and_centering_hotkeys(props, event):
    """Handles X/Y/Z/N/V/C hotkeys while placing or sliding a hole."""
    if event.value != 'PRESS':
        return False

    if event.type == 'X':
        props.axis_mode = 'NORMAL' if props.axis_mode == 'X' else 'X'
        return True
    if event.type == 'Y':
        props.axis_mode = 'NORMAL' if props.axis_mode == 'Y' else 'Y'
        return True
    if event.type == 'Z':
        props.axis_mode = 'NORMAL' if props.axis_mode == 'Z' else 'Z'
        return True
    if event.type == 'V':
        props.axis_mode = 'NORMAL' if props.axis_mode == 'VIEW' else 'VIEW'
        return True
    if event.type == 'N':
        props.axis_mode = 'NORMAL'
        return True
    if event.type == 'C':
        props.auto_center_concave = not props.auto_center_concave
        return True

    return False


def format_modal_status_bar(prefix, props):
    center_state = "ON" if props.auto_center_concave else "OFF"
    return (
        f"{prefix} | Axis: [{props.axis_mode}] (X/Y/Z/V/N) | "
        f"Curve-Center (C): [{center_state}] | [Left Click] Confirm | [Esc/Right Click] Cancel"
    )


# =========================================================================
# OPERATOR: Click to Place Hole (Single-Use with Axis/Center Hotkeys)
# =========================================================================
class MAGNET_OT_place_hole(bpy.types.Operator):
    """Click once on the model surface to cut a magnet hole"""
    bl_idname = "mesh.place_magnet_hole"
    bl_label = "Click to Place Hole"
    bl_options = {'REGISTER', 'UNDO'}

    def _disarm(self, context):
        ReticleHUD.disable()
        context.window_manager.magnet_active = False
        context.workspace.status_text_set(None)
        if context.area is not None:
            context.area.tag_redraw()

    def execute(self, context):
        return self.invoke(context, None)

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Use this tool inside the 3D Viewport.")
            return {'CANCELLED'}

        if getattr(context.window_manager, "magnet_active", False):
            self._disarm(context)
            self.report({'INFO'}, "Magnet tool cancelled.")
            return {'FINISHED'}

        if context.object is not None and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        purge_legacy_handlers_and_heal_scene()

        self.last_x = -999
        self.last_y = -999

        ReticleHUD.enable()
        CutterOverlay3D.enable()
        context.window_manager.magnet_active = True
        context.window_manager.modal_handler_add(self)
        context.workspace.status_text_set(
            format_modal_status_bar("PLACE HOLE", context.scene.magnet_props)
        )
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        props = context.scene.magnet_props

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self._disarm(context)
            self.report({'INFO'}, "Cancelled.")
            return {'FINISHED'}

        if handle_modal_axis_and_centering_hotkeys(props, event):
            context.workspace.status_text_set(format_modal_status_bar("PLACE HOLE", props))
            if context.area is not None:
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            dx = event.mouse_x - self.last_x
            dy = event.mouse_y - self.last_y
            if dx * dx + dy * dy >= 4:
                self.last_x = event.mouse_x
                self.last_y = event.mouse_y
                win_region, _ = find_viewport_region_and_rv3d(context)
                if win_region is not None:
                    ReticleHUD.update_position(event.mouse_x - win_region.x, event.mouse_y - win_region.y)
                    context.area.tag_redraw()
            return {'PASS_THROUGH'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            win_region, rv3d = find_viewport_region_and_rv3d(context)
            if win_region is None or rv3d is None:
                self._disarm(context)
                return {'CANCELLED'}

            local_x = event.mouse_x - win_region.x
            local_y = event.mouse_y - win_region.y
            if not (0 <= local_x <= win_region.width and 0 <= local_y <= win_region.height):
                return {'PASS_THROUGH'}

            coord = (local_x, local_y)
            view_vector = view3d_utils.region_2d_to_vector_3d(win_region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(win_region, rv3d, coord)

            hit_obj, hit_loc, hit_normal = raycast_scene_models(context, ray_origin, view_vector)

            if hit_obj is not None:
                create_cutter_cylinder_data_api(context, hit_obj, hit_loc, hit_normal, view_vector)
                self._disarm(context)
                dia = props.magnet_diameter + props.dia_clearance
                dep = props.magnet_depth + props.depth_clearance
                self.report({'INFO'}, f"{props.shape_type.title()} placed: Ø {dia:.2f}mm × {dep:.2f}mm")
                return {'FINISHED'}

            self.report({'WARNING'}, "Click directly on a model surface.")
            return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}


# =========================================================================
# OPERATOR: Cut Hole at 3D Cursor
# =========================================================================
class MAGNET_OT_place_at_cursor(bpy.types.Operator):
    """Cut a magnet hole at the current 3D Cursor position"""
    bl_idname = "mesh.place_magnet_at_cursor"
    bl_label = "Cut Hole at 3D Cursor"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        purge_legacy_handlers_and_heal_scene()

        target_obj = resolve_target_mesh_object(context)
        if target_obj is None:
            self.report({'WARNING'}, "Select your model first.")
            return {'CANCELLED'}

        if target_obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        cursor_world = context.scene.cursor.location.copy()
        mat_inv = target_obj.matrix_world.inverted_safe()
        cursor_local = mat_inv @ cursor_world

        hit, loc_local, norm_local, _ = target_obj.closest_point_on_mesh(cursor_local)
        if hit:
            hit_world = target_obj.matrix_world @ loc_local
            normal_world = (mat_inv.transposed().to_3x3() @ norm_local).normalized()
        else:
            hit_world = cursor_world
            normal_world = Vector((0.0, 0.0, 1.0))

        create_cutter_cylinder_data_api(context, target_obj, hit_world, normal_world)
        props = context.scene.magnet_props
        dia = props.magnet_diameter + props.dia_clearance
        dep = props.magnet_depth + props.depth_clearance
        self.report({'INFO'}, f"Hole cut at 3D Cursor: Ø {dia:.2f}mm × {dep:.2f}mm")
        return {'FINISHED'}


# =========================================================================
# OPERATOR: Slide Hole on Surface (With Live Curve-Centering & Axis Hotkeys)
# =========================================================================
class MAGNET_OT_reposition(bpy.types.Operator):
    """Slide the selected hole across the model surface"""
    bl_idname = "mesh.reposition_magnet"
    bl_label = "Slide Hole"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return self.invoke(context, None)

    def invoke(self, context, event):
        cutter = context.active_object
        if cutter is None or not cutter.get(TAG_IS_CUTTER, False):
            self.report({'WARNING'}, "Select a magnet cutter first.")
            return {'CANCELLED'}

        target_name = cutter.get(TAG_TARGET_NAME, "")
        target_obj = bpy.data.objects.get(target_name)
        if target_obj is None:
            self.report({'WARNING'}, "Target model not found.")
            return {'CANCELLED'}

        self.cutter = cutter
        self.target_obj = target_obj
        self.orig_matrix = cutter.matrix_world.copy()
        self.orig_hit_loc = tuple(cutter.get(TAG_HIT_LOC, (0.0, 0.0, 0.0)))
        self.orig_hit_norm = tuple(cutter.get(TAG_HIT_NORMAL, (0.0, 0.0, 1.0)))
        self.params = compute_cutter_parameters_from_props(context, target_obj)
        self.last_x = -999
        self.last_y = -999
        self.last_view_vec = None

        self.paused_mods = []
        for mod in target_obj.modifiers:
            if mod.type == 'BOOLEAN' and mod.name.startswith(MODIFIER_PREFIX) and mod.show_viewport:
                mod.show_viewport = False
                self.paused_mods.append(mod)

        ReticleHUD.enable()
        CutterOverlay3D.enable()
        context.window_manager.magnet_active = True
        context.window_manager.modal_handler_add(self)
        context.workspace.status_text_set(
            format_modal_status_bar("SLIDE HOLE", context.scene.magnet_props)
        )
        return {'RUNNING_MODAL'}

    def _apply_slide_position(self, context, raw_loc, raw_norm, view_vec):
        props = context.scene.magnet_props
        mat_world, final_loc, final_norm, axis_norm, eff_overshoot = compute_cutter_world_matrix(
            self.target_obj, raw_loc, raw_norm, self.params, props, view_vec
        )
        self.cutter.matrix_world = mat_world
        self.cutter[TAG_HIT_LOC] = (final_loc.x, final_loc.y, final_loc.z)
        self.cutter[TAG_HIT_NORMAL] = (final_norm.x, final_norm.y, final_norm.z)
        self.cutter[TAG_AXIS_NORMAL] = (axis_norm.x, axis_norm.y, axis_norm.z)
        self.cutter[TAG_OVERSHOOT] = eff_overshoot

    def _finish(self, context):
        ReticleHUD.disable()
        context.window_manager.magnet_active = False
        if context.scene.magnet_props.live_boolean_preview:
            for mod in self.paused_mods:
                mod.show_viewport = True
        context.workspace.status_text_set(None)
        if context.area is not None:
            context.area.tag_redraw()

    def modal(self, context, event):
        props = context.scene.magnet_props

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self.cutter.matrix_world = self.orig_matrix
            self.cutter[TAG_HIT_LOC] = self.orig_hit_loc
            self.cutter[TAG_HIT_NORMAL] = self.orig_hit_norm
            self._finish(context)
            self.report({'INFO'}, "Move cancelled.")
            return {'FINISHED'}

        if handle_modal_axis_and_centering_hotkeys(props, event):
            cur_loc = Vector(self.cutter.get(TAG_HIT_LOC, self.orig_hit_loc))
            cur_norm = Vector(self.cutter.get(TAG_HIT_NORMAL, self.orig_hit_norm))
            self._apply_slide_position(context, cur_loc, cur_norm, self.last_view_vec)
            context.workspace.status_text_set(format_modal_status_bar("SLIDE HOLE", props))
            if context.area is not None:
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            dx = event.mouse_x - self.last_x
            dy = event.mouse_y - self.last_y
            if dx * dx + dy * dy >= 4:
                self.last_x = event.mouse_x
                self.last_y = event.mouse_y

                win_region, rv3d = find_viewport_region_and_rv3d(context)
                if win_region is not None and rv3d is not None:
                    local_x = event.mouse_x - win_region.x
                    local_y = event.mouse_y - win_region.y
                    ReticleHUD.update_position(local_x, local_y)

                    coord = (local_x, local_y)
                    view_vec_world = view3d_utils.region_2d_to_vector_3d(win_region, rv3d, coord)
                    ray_orig_world = view3d_utils.region_2d_to_origin_3d(win_region, rv3d, coord)
                    self.last_view_vec = view_vec_world

                    mat_inv = self.target_obj.matrix_world.inverted_safe()
                    local_orig = mat_inv @ ray_orig_world
                    local_dir = (mat_inv.to_3x3() @ view_vec_world).normalized()

                    hit, hit_loc_local, hit_norm_local, _ = self.target_obj.ray_cast(local_orig, local_dir)
                    if hit:
                        world_loc = self.target_obj.matrix_world @ hit_loc_local
                        world_norm = (mat_inv.transposed().to_3x3() @ hit_norm_local).normalized()
                        if world_norm.dot(view_vec_world) > 0.0:
                            world_norm = -world_norm

                        self._apply_slide_position(context, world_loc, world_norm, view_vec_world)

                    context.area.tag_redraw()

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self._finish(context)
            self.report({'INFO'}, "Hole position updated.")
            return {'FINISHED'}

        return {'RUNNING_MODAL'}


# =========================================================================
# OPERATOR: Center Selected Hole on Concave / Curved Socket
# =========================================================================
class MAGNET_OT_center_on_curve(bpy.types.Operator):
    """Snap the selected hole to the geometric center of a concave socket or curved surface"""
    bl_idname = "mesh.center_magnet_on_curve"
    bl_label = "Center in Concave Socket"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        cutters = get_selected_cutters(context)
        if not cutters:
            self.report({'WARNING'}, "Select a magnet cutter first.")
            return {'CANCELLED'}

        props = context.scene.magnet_props
        centered_count = 0

        for cutter in cutters:
            target_obj = bpy.data.objects.get(cutter.get(TAG_TARGET_NAME, ""))
            if target_obj is None or target_obj.type != 'MESH':
                continue

            raw_loc = Vector(cutter.get(TAG_HIT_LOC, cutter.matrix_world.translation))
            raw_norm = Vector(cutter.get(TAG_HIT_NORMAL, (0.0, 0.0, 1.0))).normalized()
            radius = float(cutter.get(TAG_RADIUS, 1.6))

            centered_loc, centered_norm = center_on_curved_socket(
                target_obj, raw_loc, raw_norm, radius, iterations=3
            )
            cutter[TAG_HIT_LOC] = (centered_loc.x, centered_loc.y, centered_loc.z)
            cutter[TAG_HIT_NORMAL] = (centered_norm.x, centered_norm.y, centered_norm.z)
            centered_count += 1

        refresh_selected_cutter_geometry(context)
        self.report({'INFO'}, f"Centered {centered_count} hole(s) in curved socket.")
        return {'FINISHED'}


# =========================================================================
# OPERATOR: Cut Coaxial Counterpart Hole (Mating Part Matching)
# =========================================================================
class MAGNET_OT_cut_counterpart(bpy.types.Operator):
    """Project a matching hole (or specialized ball cup / alignment plug) onto the adjacent mating part"""
    bl_idname = "mesh.cut_counterpart_magnet"
    bl_label = "Cut Matching Hole on Counterpart"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global _suppress_cutter_refresh

        cutters = get_selected_cutters(context)
        cutter = context.active_object if (context.active_object and context.active_object.get(TAG_IS_CUTTER, False)) else (cutters[0] if cutters else None)
        if cutter is None or not cutter.get(TAG_IS_CUTTER, False):
            self.report({'WARNING'}, "Select an existing magnet cutter first.")
            return {'CANCELLED'}

        source_cutter = cutter
        source_target = bpy.data.objects.get(source_cutter.get(TAG_TARGET_NAME, ""))
        hit_loc = Vector(source_cutter.get(TAG_HIT_LOC, source_cutter.matrix_world.translation))
        axis_norm = Vector(source_cutter.get(TAG_AXIS_NORMAL, source_cutter.get(TAG_HIT_NORMAL, (0.0, 0.0, 1.0)))).normalized()

        # Raycast outward (+axis_norm) from inside the socket so both overlapping and gapped mates are hit
        back_offset = max(float(source_cutter.get(TAG_DEPTH, 1.0)) * 0.75, 0.25)
        mate_obj, mate_loc, _ = raycast_scene_models(
            context, hit_loc - axis_norm * back_offset, axis_norm, exclude_obj=source_target
        )
        if mate_obj is None:
            mate_obj, mate_loc, _ = raycast_scene_models(
                context, hit_loc + axis_norm * back_offset, -axis_norm, exclude_obj=source_target
            )

        if mate_obj is None:
            self.report({'WARNING'}, "No adjacent mating model found along this hole's axis.")
            return {'CANCELLED'}

        # Counterpart normal is strictly coaxial and opposite (-axis_norm) so magnets meet flush
        counter_normal = -axis_norm

        source_shape = source_cutter.get(TAG_SHAPE, 'CYLINDER')
        unit_scale, _ = resolve_unit_scale(context, source_target)

        props = context.scene.magnet_props

        # Deselect all objects so source cutter is never targeted by refresh callbacks
        for s in list(context.selected_objects):
            s.select_set(False)
        context.view_layer.objects.active = None

        _suppress_cutter_refresh = True
        try:
            props.axis_mode = 'NORMAL'
            props.auto_center_concave = False
            props.tilt_angle_x = 0.0
            props.tilt_angle_y = 0.0
            props.spin_angle_z = 0.0

            if source_shape == 'SPHERE':
                # Special non-mirror counterpart for ball bearing:
                # 1. Spherical cup matching the protruding portion of the sphere
                # 2. Cylindrical magnet hole starting at the bottom-most point of the dome
                ball_dia_mm = float(source_cutter.get("ball_dia_mm", 0.0))
                if ball_dia_mm <= 0.0:
                    ball_dia_mm = float(source_cutter.get(TAG_BALL_DIAMETER, 0.0))
                if ball_dia_mm <= 0.0:
                    src_radius = float(source_cutter.get(TAG_RADIUS, 1.5))
                    ball_dia_mm = max(0.5, (src_radius * 2.0 / unit_scale) - props.dia_clearance)

                plunge_depth_mm = float(source_cutter.get("plunge_depth_mm", 0.0))
                if plunge_depth_mm <= 0.0:
                    src_depth = float(source_cutter.get(TAG_DEPTH, 2.0))
                    plunge_depth_mm = max(0.2, (src_depth / unit_scale) - props.depth_clearance)

                # Cup depth on mating model matches whatever portion of the ball is protruding (not below surface):
                protruding_mm = max(0.2, ball_dia_mm - plunge_depth_mm)

                props.shape_type = 'BALL_SOCKET'
                props.ball_diameter = round(ball_dia_mm, 2)
                props.cup_depth = round(protruding_mm, 2)
                props.magnet_diameter = round(props.counterpart_magnet_dia, 2)
                props.magnet_depth = round(props.counterpart_magnet_depth, 2)

                new_cutter = create_cutter_cylinder_data_api(context, mate_obj, mate_loc, counter_normal)
                self.report(
                    {'INFO'},
                    f"Matched Ball Socket onto '{mate_obj.name}': Ø {ball_dia_mm:.1f}mm cup ({protruding_mm:.2f}mm deep) + Ø {props.magnet_diameter:.1f}x{props.magnet_depth:.1f}mm magnet hole at dome bottom — homogeneous {ball_dia_mm:.1f}mm fit."
                )
                return {'FINISHED'}

            elif source_shape == 'BALL_SOCKET':
                # Reverse counterpart: mating Ball Bearing for an existing Ball Socket
                ball_dia_mm = float(source_cutter.get("ball_dia_mm", source_cutter.get(TAG_BALL_DIAMETER, props.ball_diameter)))
                cup_depth_mm = float(source_cutter.get("cup_depth_mm", 0.0))
                if cup_depth_mm <= 0.0:
                    cup_d_raw = float(source_cutter.get(TAG_CUP_DEPTH, props.cup_depth))
                    cup_depth_mm = cup_d_raw / unit_scale if (cup_d_raw < 0.05 and unit_scale > 0.0) else cup_d_raw

                # The remaining plunge depth so the two models homogeneously encapsulate the ball:
                ball_plunge_mm = max(0.2, ball_dia_mm - cup_depth_mm)

                props.shape_type = 'SPHERE'
                props.magnet_diameter = round(ball_dia_mm, 2)
                props.magnet_depth = round(ball_plunge_mm, 2)

                new_cutter = create_cutter_cylinder_data_api(context, mate_obj, mate_loc, counter_normal)
                self.report(
                    {'INFO'},
                    f"Matched Ball Bearing onto '{mate_obj.name}': Ø {ball_dia_mm:.1f}mm ball ({ball_plunge_mm:.2f}mm plunge depth) — homogeneous {ball_dia_mm:.1f}mm fit."
                )
                return {'FINISHED'}

            elif source_shape == 'RING':
                src_ring_mode = source_cutter.get(TAG_RING_MODE, 'DONUT')
                props.shape_type = 'RING'
                outer_d = round(float(source_cutter.get(TAG_RADIUS, 1.5)) * 2.0 / unit_scale - props.dia_clearance, 2)
                inner_d = round(float(source_cutter.get(TAG_INNER_RADIUS, 0.75)) * 2.0 / unit_scale + props.dia_clearance, 2)
                src_mag_depth = round(float(source_cutter.get(TAG_DEPTH, 2.0)) / unit_scale - props.depth_clearance, 2)

                if src_ring_mode == 'DONUT':
                    props.ring_mode = 'DONUT'
                    props.magnet_diameter = outer_d
                    props.inner_diameter = inner_d
                    props.magnet_depth = round(src_mag_depth, 2)

                    new_cutter = create_cutter_cylinder_data_api(context, mate_obj, mate_loc, counter_normal)
                    self.report(
                        {'INFO'},
                        f"Matched Donut Hole onto '{mate_obj.name}': OD {props.magnet_diameter:.1f}mm / ID {props.inner_diameter:.1f}mm × {props.magnet_depth:.1f}mm (intact center post)."
                    )
                    return {'FINISHED'}

                elif src_ring_mode == 'PLUG':
                    cp_mag_depth = float(source_cutter.get("counterpart_mag_depth_mm", 0.0))
                    if cp_mag_depth <= 0.0:
                        cp_d_raw = float(source_cutter.get(TAG_COUNTERPART_DEPTH, 0.0))
                        cp_mag_depth = (cp_d_raw / unit_scale - props.depth_clearance) if cp_d_raw > 0.0 else src_mag_depth

                    props.ring_mode = 'FULL'
                    props.magnet_diameter = outer_d
                    props.inner_diameter = inner_d
                    props.magnet_depth = round(cp_mag_depth, 2)
                    props.counterpart_magnet_depth = round(src_mag_depth, 2)

                    new_cutter = create_cutter_cylinder_data_api(context, mate_obj, mate_loc, counter_normal)
                    self.report(
                        {'INFO'},
                        f"Matched Full Hole onto '{mate_obj.name}': Ø {props.magnet_diameter:.1f}mm × {props.magnet_depth:.1f}mm (full hole to receive donut magnet & mating peg column)."
                    )
                    return {'FINISHED'}

                else:  # src_ring_mode == 'FULL'
                    props.ring_mode = 'PLUG'
                    props.magnet_diameter = outer_d
                    props.inner_diameter = inner_d
                    props.counterpart_magnet_depth = round(src_mag_depth, 2)

                    new_cutter = create_cutter_cylinder_data_api(context, mate_obj, mate_loc, counter_normal)
                    total_col_h = props.magnet_depth + props.counterpart_magnet_depth
                    self.report(
                        {'INFO'},
                        f"Matched Ring Fitment Plug onto '{mate_obj.name}': Relief Cut Ø {props.magnet_diameter:.1f}mm ({props.magnet_depth:.1f}mm deep) + Column Ø {props.inner_diameter:.1f}mm ({total_col_h:.1f}mm total, protruding {props.counterpart_magnet_depth:.1f}mm)."
                    )
                    return {'FINISHED'}

            elif source_shape == 'BAR':
                props.shape_type = 'BAR'
                props.magnet_diameter = round(float(source_cutter.get(TAG_RADIUS, 1.5)) * 2.0 / unit_scale - props.dia_clearance, 2)
                props.bar_length = round(float(source_cutter.get(TAG_BAR_LENGTH, 6.0)) / unit_scale - props.dia_clearance, 2)
                props.magnet_depth = round(float(source_cutter.get(TAG_DEPTH, 2.0)) / unit_scale - props.depth_clearance, 2)

                new_cutter = create_cutter_cylinder_data_api(context, mate_obj, mate_loc, counter_normal)
                self.report({'INFO'}, f"Matched Bar hole onto '{mate_obj.name}'.")
                return {'FINISHED'}

            else:
                props.shape_type = 'CYLINDER'
                props.magnet_diameter = round(float(source_cutter.get(TAG_RADIUS, 1.5)) * 2.0 / unit_scale - props.dia_clearance, 2)
                props.magnet_depth = round(float(source_cutter.get(TAG_DEPTH, 2.0)) / unit_scale - props.depth_clearance, 2)

                new_cutter = create_cutter_cylinder_data_api(context, mate_obj, mate_loc, counter_normal)
                self.report({'INFO'}, f"Matched coaxial hole onto '{mate_obj.name}'.")
                return {'FINISHED'}

        finally:
            _suppress_cutter_refresh = False


# =========================================================================
# OPERATORS: Scale, Delete, Apply, Clear, Sync
# =========================================================================
class MAGNET_OT_apply_controls_to_selected(bpy.types.Operator):
    """Apply current panel controls (size, depth, tolerances, shape) to selected hole(s)"""
    bl_idname = "mesh.apply_controls_to_selected_cutter"
    bl_label = "Update / Apply Controls to Selected Hole"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global _suppress_cutter_refresh
        _suppress_cutter_refresh = False

        cutters = get_selected_cutters(context)
        if not cutters:
            self.report({'WARNING'}, "Select a magnet cutter first.")
            return {'CANCELLED'}

        refresh_selected_cutter_geometry(context)
        CutterOverlay3D.invalidate_cache()
        if context.area is not None:
            context.area.tag_redraw()

        num = len(cutters)
        msg = f"Applied panel controls to {num} selected hole." if num == 1 else f"Applied panel controls to {num} selected holes."
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class MAGNET_OT_sync_from_selected(bpy.types.Operator):
    """Load selected cutter properties into panel sliders"""
    bl_idname = "mesh.sync_from_selected_cutter"
    bl_label = "Sync Controls from Selected Hole"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global _suppress_cutter_refresh
        cutters = get_selected_cutters(context)
        if not cutters:
            self.report({'WARNING'}, "Select a magnet cutter first.")
            return {'CANCELLED'}

        cutter = cutters[0]
        props = context.scene.magnet_props
        shape = cutter.get(TAG_SHAPE, 'CYLINDER')

        target_obj = bpy.data.objects.get(cutter.get(TAG_TARGET_NAME, ""))
        unit_scale, _ = resolve_unit_scale(context, target_obj)

        _suppress_cutter_refresh = True
        try:
            props.shape_type = shape

            if shape == 'SPHERE':
                props.magnet_diameter = round(float(cutter.get("ball_dia_mm", (float(cutter.get(TAG_RADIUS, 1.5)) * 2.0 / unit_scale) - props.dia_clearance)), 2)
                props.magnet_depth = round(float(cutter.get("plunge_depth_mm", (float(cutter.get(TAG_DEPTH, 2.0)) / unit_scale) - props.depth_clearance)), 2)
            elif shape == 'BALL_SOCKET':
                props.ball_diameter = round(float(cutter.get("ball_dia_mm", cutter.get(TAG_BALL_DIAMETER, props.ball_diameter))), 2)
                cup_d = float(cutter.get("cup_depth_mm", 0.0))
                if cup_d <= 0.0:
                    cup_d_raw = float(cutter.get(TAG_CUP_DEPTH, props.cup_depth))
                    cup_d = cup_d_raw / unit_scale if (cup_d_raw < 0.05 and unit_scale > 0.0) else cup_d_raw
                props.cup_depth = round(cup_d, 2)
                props.magnet_diameter = round(float(cutter.get("magnet_dia_mm", props.counterpart_magnet_dia)), 2)
                props.magnet_depth = round(float(cutter.get("magnet_depth_mm", props.counterpart_magnet_depth)), 2)
            elif shape == 'RING':
                props.ring_mode = cutter.get(TAG_RING_MODE, 'DONUT')
                props.magnet_diameter = round(float(cutter.get(TAG_RADIUS, 1.5)) * 2.0 / unit_scale - props.dia_clearance, 2)
                props.inner_diameter = round(float(cutter.get(TAG_INNER_RADIUS, 0.75)) * 2.0 / unit_scale + props.dia_clearance, 2)
                props.magnet_depth = round(float(cutter.get(TAG_DEPTH, 2.0)) / unit_scale - props.depth_clearance, 2)
                cp_mag_d = float(cutter.get("counterpart_mag_depth_mm", 0.0))
                if cp_mag_d <= 0.0:
                    cp_d_raw = float(cutter.get(TAG_COUNTERPART_DEPTH, 0.0))
                    cp_mag_d = (cp_d_raw / unit_scale - props.depth_clearance) if cp_d_raw > 0.0 else props.magnet_depth
                props.counterpart_magnet_depth = round(cp_mag_d, 2)
            elif shape == 'BAR':
                props.magnet_diameter = round(float(cutter.get(TAG_RADIUS, 1.5)) * 2.0 / unit_scale - props.dia_clearance, 2)
                props.bar_length = round(float(cutter.get(TAG_BAR_LENGTH, 6.0)) / unit_scale - props.dia_clearance, 2)
                props.magnet_depth = round(float(cutter.get(TAG_DEPTH, 2.0)) / unit_scale - props.depth_clearance, 2)
            else:
                props.magnet_diameter = round(float(cutter.get(TAG_RADIUS, 1.5)) * 2.0 / unit_scale - props.dia_clearance, 2)
                props.magnet_depth = round(float(cutter.get(TAG_DEPTH, 2.0)) / unit_scale - props.depth_clearance, 2)
        finally:
            _suppress_cutter_refresh = False

        self.report({'INFO'}, f"Loaded {shape.title()} settings into panel controls.")
        return {'FINISHED'}


class MAGNET_OT_apply_target_scale(bpy.types.Operator):
    """Apply object scale so holes cut round instead of stretched"""
    bl_idname = "mesh.apply_target_scale"
    bl_label = "Fix Object Scale"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = resolve_target_mesh_object(context)
        if obj is not None:
            for selected in context.selected_objects:
                selected.select_set(False)
            obj.select_set(True)
            context.view_layer.objects.active = obj
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            self.report({'INFO'}, f"Scale applied on {obj.name}.")
            return {'FINISHED'}
        return {'CANCELLED'}


class MAGNET_OT_remove_selected(bpy.types.Operator):
    """Delete selected magnet cylinder and remove its Boolean modifier from the model"""
    bl_idname = "mesh.remove_magnet_socket"
    bl_label = "Delete Selected Hole"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        cutters = get_selected_cutters(context)
        if not cutters:
            cleanup_orphan_modifiers_and_collections()
            self.report({'WARNING'}, "Select a magnet cutter first.")
            return {'CANCELLED'}

        removed_count = 0
        for cutter in list(cutters):
            if cutter.name in bpy.data.objects:
                delete_cutter_and_associated_pegs(cutter)
                removed_count += 1

        cleanup_orphan_modifiers_and_collections()
        CutterOverlay3D.invalidate_cache()
        self.report({'INFO'}, f"Removed {removed_count} magnet hole(s).")
        return {'FINISHED'}


class MAGNET_OT_apply_all(bpy.types.Operator):
    """Permanently apply all magnet holes into the model for 3D printing"""
    bl_idname = "mesh.apply_all_magnets"
    bl_label = "Apply All Holes (For 3D Print)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        purge_legacy_handlers_and_heal_scene()

        cutters = [o for o in bpy.data.objects if o.get(TAG_IS_CUTTER, False)]
        if not cutters:
            cleanup_orphan_modifiers_and_collections()
            self.report({'INFO'}, "No unapplied magnet holes found.")
            return {'FINISHED'}

        props = context.scene.magnet_props
        target_objects = set()

        for cutter in cutters:
            target_obj = bpy.data.objects.get(cutter.get(TAG_TARGET_NAME, ""))
            if target_obj is not None and target_obj.type == 'MESH':
                target_objects.add(target_obj)

        applied = 0
        cutter_set = set(cutters)
        for target_obj in target_objects:
            if target_obj.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')

            for selected in context.selected_objects:
                selected.select_set(False)
            target_obj.select_set(True)
            context.view_layer.objects.active = target_obj

            for mod in list(target_obj.modifiers):
                if mod.type == 'BOOLEAN' and (mod.object in cutter_set or mod.name.startswith(MODIFIER_PREFIX)):
                    if mod.object is not None:
                        mod.show_viewport = True
                        assign_valid_boolean_solver(mod, props.boolean_solver)
                        bpy.ops.object.modifier_apply(modifier=mod.name)
                        applied += 1
                    else:
                        target_obj.modifiers.remove(mod)

        for cutter in cutters:
            mesh_data = cutter.data
            bpy.data.objects.remove(cutter, do_unlink=True)
            if mesh_data is not None and mesh_data.users == 0:
                bpy.data.meshes.remove(mesh_data)

        CutterOverlay3D.invalidate_cache()
        cleanup_orphan_modifiers_and_collections()
        self.report({'INFO'}, f"Applied {applied} hole(s)/plug(s). Model is ready for STL export!")
        return {'FINISHED'}


class MAGNET_OT_clean_cutters(bpy.types.Operator):
    """Remove all unapplied magnet cylinders and modifiers"""
    bl_idname = "mesh.clean_magnet_cutters"
    bl_label = "Clear All Unapplied Holes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        purge_legacy_handlers_and_heal_scene()

        cutters = [
            o for o in bpy.data.objects
            if o.get(TAG_IS_CUTTER, False) or o.name.startswith("Magnet_")
        ]
        for cutter in cutters:
            target_obj = bpy.data.objects.get(cutter.get(TAG_TARGET_NAME, ""))
            if target_obj is not None:
                for mod in list(target_obj.modifiers):
                    if mod.type == 'BOOLEAN' and mod.object == cutter:
                        target_obj.modifiers.remove(mod)

            mesh_data = cutter.data
            bpy.data.objects.remove(cutter, do_unlink=True)
            if mesh_data is not None and mesh_data.users == 0:
                bpy.data.meshes.remove(mesh_data)

        CutterOverlay3D.invalidate_cache()
        cleanup_orphan_modifiers_and_collections()
        self.report({'INFO'}, "Cleared all unapplied holes and modifiers.")
        return {'FINISHED'}


# =========================================================================
# SIMPLE, USER-FRIENDLY UI PANEL
# =========================================================================
class MAGNET_PT_main_panel(bpy.types.Panel):
    bl_label = "Magnet Hole Cutter"
    bl_idname = "MAGNET_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Magnet Tool"

    def draw(self, context):
        layout = self.layout
        props = context.scene.magnet_props
        is_active = getattr(context.window_manager, "magnet_active", False)
        active_obj = context.active_object
        selected_cutters = get_selected_cutters(context)
        is_cutter_selected = bool(selected_cutters)
        active_cutter = selected_cutters[0] if selected_cutters else (
            active_obj if (active_obj is not None and active_obj.get(TAG_IS_CUTTER, False)) else None
        )

        target_model = resolve_target_mesh_object(context)
        if target_model is not None:
            sc = target_model.scale
            if abs(sc.x - 1.0) > 0.001 or abs(sc.y - 1.0) > 0.001 or abs(sc.z - 1.0) > 0.001:
                box_warn = layout.box()
                box_warn.label(text="Model Scale Not Applied!", icon='ERROR')
                box_warn.operator("mesh.apply_target_scale", text="Fix Model Scale", icon='CHECKMARK')

        # 1. Main Place Buttons
        col_main = layout.column(align=True)
        col_main.scale_y = 1.75
        if is_active:
            col_main.alert = True
            col_main.operator("mesh.place_magnet_hole", text="[Active] Click Model (or Cancel)", icon='CANCEL')
        else:
            col_main.operator("mesh.place_magnet_hole", text="Click to Place Hole", icon='SNAP_FACE')

        row_cur = layout.row(align=True)
        row_cur.scale_y = 1.2
        row_cur.operator("mesh.place_magnet_at_cursor", text="Cut at 3D Cursor", icon='CURSOR')
        sub_mate = row_cur.row(align=True)
        sub_mate.enabled = is_cutter_selected
        sub_mate.operator("mesh.cut_counterpart_magnet", text="Match Counterpart", icon='MOD_MIRROR')

        if is_cutter_selected and active_cutter and active_cutter.get(TAG_SHAPE) == 'SPHERE':
            box_cp = layout.box()
            box_cp.label(text="Ball Bearing Counterpart Settings:", icon='SNAP_FACE')
            row_cp = box_cp.row(align=True)
            row_cp.prop(props, "counterpart_magnet_dia", text="Magnet Ø (mm)")
            row_cp.prop(props, "counterpart_magnet_depth", text="Magnet Depth (mm)")
            unit_sc, _ = resolve_unit_scale(context, target_model)
            ball_dia = float(active_cutter.get("ball_dia_mm", active_cutter.get(TAG_BALL_DIAMETER, 0.0)))
            if ball_dia <= 0.0:
                ball_dia = max(0.5, (float(active_cutter.get(TAG_RADIUS, 1.5)) * 2.0 / unit_sc) - props.dia_clearance)
            plunge_d = float(active_cutter.get("plunge_depth_mm", 0.0))
            if plunge_d <= 0.0:
                plunge_d = max(0.2, (float(active_cutter.get(TAG_DEPTH, 2.0)) / unit_sc) - props.depth_clearance)
            protrude_est = max(0.2, round(ball_dia - plunge_d, 2))
            box_cp.label(
                text=f"Protruding: ~{protrude_est:.2f}mm cup + magnet at dome bottom",
                icon='INFO'
            )
            box_cp.label(
                text=f"Homogeneous: {plunge_d:.2f}mm seated + {protrude_est:.2f}mm cup = {ball_dia:.1f}mm",
                icon='CHECKMARK'
            )

        elif is_cutter_selected and active_cutter and active_cutter.get(TAG_SHAPE) == 'BALL_SOCKET':
            box_cp = layout.box()
            box_cp.label(text="Ball Bearing Counterpart:", icon='SNAP_FACE')
            unit_sc, _ = resolve_unit_scale(context, target_model)
            ball_dia = float(active_cutter.get("ball_dia_mm", active_cutter.get(TAG_BALL_DIAMETER, props.ball_diameter)))
            cup_d = float(active_cutter.get("cup_depth_mm", 0.0))
            if cup_d <= 0.0:
                cup_d_raw = float(active_cutter.get(TAG_CUP_DEPTH, props.cup_depth))
                cup_d = cup_d_raw / unit_sc if (cup_d_raw < 0.05 and unit_sc > 0.0) else cup_d_raw
            cup_d = round(cup_d, 2)
            rem_plunge = max(0.2, round(ball_dia - cup_d, 2))
            box_cp.label(
                text=f"Mating Ball Plunge: ~{rem_plunge:.2f}mm (Ball Bearing)",
                icon='INFO'
            )
            box_cp.label(
                text=f"Homogeneous: {cup_d:.2f}mm cup + {rem_plunge:.2f}mm ball = {ball_dia:.1f}mm",
                icon='CHECKMARK'
            )

        elif is_cutter_selected and active_cutter and active_cutter.get(TAG_SHAPE) == 'RING':
            box_cp = layout.box()
            ring_m = active_cutter.get(TAG_RING_MODE, 'DONUT')
            if ring_m == 'PLUG':
                box_cp.label(text="Ring Fitment Plug (Relief Cut + Peg Column):", icon='SNAP_FACE')
                box_cp.label(text="Relief Cut: Flush donut magnet socket beneath surface", icon='INFO')
                unit_sc, _ = resolve_unit_scale(context, target_model)
                src_mag_d = float(active_cutter.get(TAG_DEPTH, 2.0)) / unit_sc if unit_sc > 0.0 else float(active_cutter.get(TAG_DEPTH, 2.0))
                cp_mag_d = float(active_cutter.get(TAG_COUNTERPART_DEPTH, active_cutter.get(TAG_DEPTH, 2.0))) / unit_sc if unit_sc > 0.0 else float(active_cutter.get(TAG_DEPTH, 2.0))
                total_col = src_mag_d + cp_mag_d
                box_cp.label(text=f"Extruded Column: {total_col:.2f}mm total height ({cp_mag_d:.2f}mm protrusion enters counterpart)", icon='CHECKMARK')
                box_cp.label(text="Counterpart: Matched model gets Full Hole to receive peg & magnet", icon='DOT')
            elif ring_m == 'FULL':
                box_cp.label(text="Ring Full Socket (Open Center):", icon='SNAP_FACE')
                box_cp.label(text="Counterpart: Matched model gets Fitment Plug (Relief Cut + Peg)", icon='DOT')
            else:
                box_cp.label(text="Ring Donut Socket (Intact Center Post):", icon='SNAP_FACE')
                box_cp.label(text="Counterpart: Matched model gets matching Donut Hole (Intact Center Post)", icon='DOT')

        # 2. Move, Center or Delete
        box_edit = layout.box()
        box_edit.label(text="Adjust Selected Hole", icon='GIZMO')

        row_slide = box_edit.row(align=True)
        row_slide.scale_y = 1.25
        row_slide.enabled = is_cutter_selected
        row_slide.operator("mesh.reposition_magnet", text="Slide on Surface", icon='EMPTY_AXIS')
        row_slide.operator("mesh.center_magnet_on_curve", text="Center in Socket", icon='SNAP_FACE_CENTER')

        row_apply = box_edit.row(align=True)
        row_apply.scale_y = 1.25
        row_apply.enabled = is_cutter_selected
        btn_apply_text = (
            f"Update / Apply Controls to {len(selected_cutters)} Selected Holes"
            if len(selected_cutters) > 1
            else "Update / Apply Controls to Selected Hole"
        )
        row_apply.operator("mesh.apply_controls_to_selected_cutter", text=btn_apply_text, icon='FILE_REFRESH')

        row_sync = box_edit.row(align=True)
        row_sync.enabled = is_cutter_selected
        row_sync.operator("mesh.sync_from_selected_cutter", text="Sync Controls from Selected Hole", icon='RESTRICT_SELECT_OFF')

        row_del = box_edit.row(align=True)
        row_del.scale_y = 1.15
        row_del.enabled = is_cutter_selected
        row_del.operator("mesh.remove_magnet_socket", text="Delete Selected Hole", icon='TRASH')

        if not is_cutter_selected:
            box_edit.label(text="Select a cutter to slide, center, match, or resize.", icon='INFO')

        layout.separator()

        # 3. Shape & Dimensions
        box_size = layout.box()
        box_size.label(text="Magnet Shape & Size", icon='MESH_CYLINDER')
        if is_cutter_selected and active_cutter and active_cutter.get(TAG_SHAPE) != props.shape_type:
            shape_name = active_cutter.get(TAG_SHAPE, '').title()
            row_shape_sync = box_size.row(align=True)
            row_shape_sync.operator(
                "mesh.apply_controls_to_selected_cutter",
                text=f"Update Hole to {props.shape_type.title()}",
                icon='FILE_REFRESH',
            )
            row_shape_sync.operator(
                "mesh.sync_from_selected_cutter",
                text=f"Match Controls to Hole ({shape_name})",
                icon='RESTRICT_SELECT_OFF',
            )
        box_size.prop(props, "shape_type", text="Shape")

        if props.shape_type == 'RING':
            box_size.prop(props, "ring_mode", text="Ring Action")

        if props.shape_type in {'CYLINDER', 'SPHERE'}:
            box_size.prop(props, "magnet_preset", text="Preset")

        col_dims = box_size.column(align=True)
        if props.shape_type == 'SPHERE':
            col_dims.prop(props, "magnet_diameter", text="Ball Diameter (mm)")
            col_dims.prop(props, "magnet_depth", text="Plunge Depth (mm)")
        elif props.shape_type == 'BALL_SOCKET':
            col_dims.label(text="Protruding Ball Cup:", icon='MESH_UVSPHERE')
            row_ball = col_dims.row(align=True)
            row_ball.prop(props, "ball_diameter", text="Ball Ø (mm)")
            row_ball.prop(props, "cup_depth", text="Cup Depth (mm)")
            col_dims.label(text="Cylindrical Magnet at Dome Bottom:", icon='MESH_CYLINDER')
            col_dims.prop(props, "magnet_preset", text="Preset")
            row_mag = col_dims.row(align=True)
            row_mag.prop(props, "magnet_diameter", text="Magnet Ø (mm)")
            row_mag.prop(props, "magnet_depth", text="Magnet Depth (mm)")
        elif props.shape_type == 'RING':
            col_dims.prop(props, "magnet_diameter", text="Outer Diameter (mm)")
            col_dims.prop(props, "inner_diameter", text="Inner Hole (mm)")
            col_dims.prop(props, "magnet_depth", text="Relief Cut Depth (mm)" if props.ring_mode == 'PLUG' else "Depth / Height (mm)")
            if props.ring_mode == 'PLUG':
                col_dims.prop(props, "counterpart_magnet_depth", text="Counterpart Mag Depth (mm)")
        elif props.shape_type == 'BAR':
            col_dims.prop(props, "magnet_diameter", text="Width X (mm)")
            col_dims.prop(props, "bar_length", text="Length Y (mm)")
            col_dims.prop(props, "magnet_depth", text="Depth Z (mm)")
        else:
            col_dims.prop(props, "magnet_diameter", text="Diameter (mm)")
            col_dims.prop(props, "magnet_depth", text="Depth (mm)")

        layout.separator()

        # 4. Concave Centering & Axis Lock
        box_align = layout.box()
        box_align.label(text="Curve Centering & Axis Lock", icon='ORIENTATION_NORMAL')
        box_align.prop(props, "auto_center_concave", text="Auto-Center on Concave / Curved Surface")
        box_align.prop(props, "depth_reference", text="Depth From")
        box_align.prop(props, "axis_mode", text="Axis Lock")

        col_angles = box_align.column(align=True)
        row_tilt = col_angles.row(align=True)
        row_tilt.prop(props, "tilt_angle_x", text="Tilt X")
        row_tilt.prop(props, "tilt_angle_y", text="Tilt Y")
        if props.shape_type == 'BAR' or abs(props.spin_angle_z) > 0.001:
            col_angles.prop(props, "spin_angle_z", text="Rotate Z")

        layout.separator()

        # 5. Fit, Chamfer & Glue Space
        box_tol = layout.box()
        box_tol.label(text="Fit, Chamfer & Glue Space", icon='TOOL_SETTINGS')
        col_tol = box_tol.column(align=True)
        col_tol.prop(props, "dia_clearance", text="Extra Width (+mm)")
        col_tol.prop(props, "depth_clearance", text="Extra Depth (+mm)")

        row_prof = box_tol.row(align=True)
        row_prof.prop(props, "use_entry_chamfer", text="45° Entry Chamfer")
        if props.shape_type in {'CYLINDER', 'BAR', 'BALL_SOCKET'}:
            row_prof.prop(props, "use_glue_relief", text="Glue Dimple")

        if props.use_entry_chamfer:
            box_tol.prop(props, "chamfer_size", text="Chamfer Lip (mm)")

        final_dia = props.magnet_diameter + props.dia_clearance
        final_dep = props.magnet_depth + props.depth_clearance
        if props.shape_type == 'RING':
            final_in = max(0.3, props.inner_diameter - props.dia_clearance)
            if props.ring_mode == 'PLUG':
                peg_protrude = props.counterpart_magnet_depth + props.depth_clearance
                col_total_h = final_dep + peg_protrude
                box_tol.label(
                    text=f"Relief Cut: OD {final_dia:.2f} / ID {final_in:.2f} × {final_dep:.2f}mm deep (flush magnet)",
                    icon='INFO'
                )
                box_tol.label(
                    text=f"Extruded Column: Ø {final_in:.2f}mm × {col_total_h:.2f}mm total (+{peg_protrude:.2f}mm protrusion)",
                    icon='CHECKMARK'
                )
            else:
                box_tol.label(
                    text=f"Ring: OD {final_dia:.2f} / ID {final_in:.2f} × {final_dep:.2f}mm",
                    icon='INFO'
                )
        elif props.shape_type == 'BALL_SOCKET':
            box_tol.label(
                text=f"Cup: Ø {props.ball_diameter:.1f}mm × {props.cup_depth:.2f}mm | Mag: Ø {final_dia:.2f}mm × {final_dep:.2f}mm",
                icon='INFO'
            )
        else:
            box_tol.label(
                text=f"Cut Size: Ø {final_dia:.2f}mm × {final_dep:.2f}mm deep",
                icon='INFO'
            )

        layout.separator()

        # 6. Visual Guide & Cylinder Facets
        box_vis = layout.box()
        box_vis.label(text="Cutter Display & Facets", icon='SHADING_RENDERED')
        box_vis.prop(props, "display_mode", text="Look")
        if props.shape_type != 'BAR':
            box_vis.prop(props, "segments", text="Facets (Sides)")
        box_vis.prop(props, "show_surface_ring", text="Show Surface Intersection Ring")
        box_vis.prop(props, "live_boolean_preview", text="Live Cut Preview in Viewport")

        layout.separator()

        # 7. Finish / Export
        box_fin = layout.box()
        box_fin.label(text="Finish", icon='CHECKMARK')
        row_app = box_fin.row()
        row_app.scale_y = 1.4
        row_app.operator("mesh.apply_all_magnets", text="Apply All Holes (For 3D Print)", icon='CHECKMARK')
        box_fin.operator("mesh.clean_magnet_cutters", text="Clear All Unapplied Holes", icon='TRASH')

        layout.separator()

        # 8. Settings
        box_set = layout.box()
        box_set.label(text="Settings", icon='PREFERENCES')
        box_set.prop(props, "scale_mode", text="Units")
        _, scale_label = resolve_unit_scale(context, target_model)
        box_set.label(text=scale_label, icon='DOT')
        box_set.prop(props, "boolean_solver", text="Solver")


# =========================================================================
# PROPERTIES & REGISTRATION
# =========================================================================
class MagnetProperties(bpy.types.PropertyGroup):
    shape_type: EnumProperty(
        name="Shape",
        items=[
            ("CYLINDER", "Disc / Cylinder Magnet", "Standard cylindrical magnet socket"),
            ("SPHERE", "Ball Bearing / Sphere (Auto-Sleeve)", "Spherical ball socket with automatic entry shaft when plunged deep"),
            ("BALL_SOCKET", "Ball Cup + Magnet Socket", "Spherical cup for protruding ball bearing with cylindrical magnet hole at the bottom"),
            ("RING", "Ring Magnet / Fitment Plug", "Donut hole with center post, full socket, or protruding alignment plug"),
            ("BAR", "Bar / Rectangular Magnet", "Rectangular slot for thin blades, banners, and armor panels"),
        ],
        default="CYLINDER",
        update=update_dimensions_or_facets,
    )

    ring_mode: EnumProperty(
        name="Ring Action",
        items=[
            ("DONUT", "Donut Hole (Keep Center Post)", "Cuts the ring groove and leaves the center resin pin intact (matches matching donut hole on counterpart)"),
            ("PLUG", "Fitment Plug (Relief Cut + Peg)", "Cuts relief pocket for donut magnet with a protruding alignment peg (matches full hole on counterpart)"),
            ("FULL", "Full Hole (Remove Center Post)", "Cuts the entire outer circle so a mating peg can enter (matches fitment plug on counterpart)"),
        ],
        default="DONUT",
        update=update_dimensions_or_facets,
    )

    magnet_preset: EnumProperty(
        name="Preset",
        items=[
            ("2x2", "2 x 2 mm (Small Arms / Wrists)", ""),
            ("3x2", "3 x 2 mm (Standard Shoulders / Arms)", ""),
            ("4x2", "4 x 2 mm (Heavy Weapons)", ""),
            ("5x2", "5 x 2 mm (Walkers / Vehicles)", ""),
            ("6x2", "6 x 2 mm (Large Monsters)", ""),
            ("2x1", "2 x 1 mm (Shallow)", ""),
            ("3x1", "3 x 1 mm (Shallow)", ""),
            ("CUSTOM", "Custom Size", ""),
        ],
        default="3x2",
        update=update_preset,
    )

    magnet_diameter: FloatProperty(
        name="Diameter / Width",
        description="Outer width or diameter in millimeters",
        default=3.0,
        min=0.5,
        max=50.0,
        update=update_dimensions_or_facets,
    )

    ball_diameter: FloatProperty(
        name="Ball Diameter",
        description="Diameter of the mating ball bearing in millimeters",
        default=3.0,
        min=0.5,
        max=50.0,
        update=update_dimensions_or_facets,
    )

    cup_depth: FloatProperty(
        name="Cup Depth",
        description="Depth of the spherical dome cup in millimeters (matches the portion of the ball protruding from mating surface)",
        default=1.0,
        min=0.1,
        max=25.0,
        update=update_dimensions_or_facets,
    )

    counterpart_magnet_dia: FloatProperty(
        name="Counterpart Magnet Diameter",
        description="Diameter of the cylindrical disc magnet to place at the bottom of the mating ball cup in millimeters",
        default=2.0,
        min=0.5,
        max=25.0,
    )

    counterpart_magnet_depth: FloatProperty(
        name="Counterpart Magnet Depth",
        description="Depth/thickness of the mating counterpart's donut magnet or ball cup magnet in millimeters",
        default=2.0,
        min=0.2,
        max=25.0,
        update=update_dimensions_or_facets,
    )

    inner_diameter: FloatProperty(
        name="Inner Hole Diameter",
        description="Inner hole diameter of the ring magnet in millimeters (shrunk by clearance for fitment)",
        default=1.5,
        min=0.3,
        max=45.0,
        update=update_dimensions_or_facets,
    )

    bar_length: FloatProperty(
        name="Bar Length (Y)",
        description="Length of rectangular bar magnet in millimeters",
        default=6.0,
        min=0.5,
        max=80.0,
        update=update_dimensions_or_facets,
    )

    magnet_depth: FloatProperty(
        name="Depth",
        description="Magnet thickness or plunge depth in millimeters",
        default=2.0,
        min=0.2,
        max=50.0,
        update=update_dimensions_or_facets,
    )

    auto_center_concave: BoolProperty(
        name="Auto-Center on Curved Surface",
        description="Sample local surface curvature to automatically center and align inside concave sockets or domes",
        default=False,
        update=update_dimensions_or_facets,
    )

    depth_reference: EnumProperty(
        name="Depth From",
        items=[
            ("CENTER", "Center Point (Standard)", "Measure hole depth from the center hit point"),
            ("LOWEST_RIM", "Lowest Rim Edge (Flush on Curves)", "Measure depth from the lowest perimeter point so the magnet never overhangs on domes"),
        ],
        default="CENTER",
        update=update_dimensions_or_facets,
    )

    axis_mode: EnumProperty(
        name="Axis Lock",
        items=[
            ("NORMAL", "Surface Normal (Auto)", "Align perpendicular to the model surface"),
            ("VIEW", "Viewport Camera (V)", "Align to current 3D Viewport camera angle"),
            ("X", "Lock to X Axis (X)", "Lock cutter horizontally along World X axis"),
            ("Y", "Lock to Y Axis (Y)", "Lock cutter horizontally along World Y axis"),
            ("Z", "Lock to Z Axis (Z)", "Lock cutter vertically along World Z axis"),
        ],
        default="NORMAL",
        update=update_dimensions_or_facets,
    )

    tilt_angle_x: FloatProperty(
        name="Tilt X (°)",
        description="Tilt cutter angle along local X axis in degrees",
        default=0.0,
        min=-90.0,
        max=90.0,
        update=update_dimensions_or_facets,
    )

    tilt_angle_y: FloatProperty(
        name="Tilt Y (°)",
        description="Tilt cutter angle along local Y axis in degrees",
        default=0.0,
        min=-90.0,
        max=90.0,
        update=update_dimensions_or_facets,
    )

    spin_angle_z: FloatProperty(
        name="Rotate Z (°)",
        description="Rotate cutter around its drilling axis in degrees",
        default=0.0,
        min=-180.0,
        max=180.0,
        update=update_dimensions_or_facets,
    )

    dia_clearance: FloatProperty(
        name="Extra Width",
        description="Extra clearance for resin shrinkage (expands outer hole and shrinks ring inner post/plug)",
        default=0.20,
        min=0.0,
        max=2.0,
        update=update_dimensions_or_facets,
    )

    depth_clearance: FloatProperty(
        name="Extra Depth",
        description="Extra depth for glue so the magnet does not stick out",
        default=0.30,
        min=0.0,
        max=2.0,
        update=update_dimensions_or_facets,
    )

    use_entry_chamfer: BoolProperty(
        name="45° Entry Chamfer",
        description="Add a 45° bevel lip at the surface entry rim so magnets guide in smoothly without resin elephant-foot catch",
        default=False,
        update=update_dimensions_or_facets,
    )

    chamfer_size: FloatProperty(
        name="Chamfer Lip (mm)",
        description="Width and depth of the 45° top entry bevel in millimeters",
        default=0.25,
        min=0.05,
        max=1.5,
        update=update_dimensions_or_facets,
    )

    use_glue_relief: BoolProperty(
        name="Glue Relief Dimple",
        description="Add a small center recess at the floor of the hole so excess superglue has a reservoir",
        default=False,
        update=update_dimensions_or_facets,
    )

    display_mode: EnumProperty(
        name="Cutter Look",
        items=[
            ("SHADOW", "Smooth Shadow Container", "Smooth dark shaded hole volume with no facet lines"),
            ("FACETS", "Solid Facets", "Show flat polygon facets and edges on the cutter"),
            ("WIRE", "Wireframe Cage", "Classic see-through wireframe cutter"),
        ],
        default="SHADOW",
        update=update_display_style,
    )

    segments: IntProperty(
        name="Facets (Sides)",
        description="Number of polygon facets around the cutter (updates selected hole live)",
        default=36,
        min=12,
        max=128,
        update=update_dimensions_or_facets,
    )

    show_surface_ring: BoolProperty(
        name="Show Surface Intersection Ring",
        description="Draw a glowing ring where the model surface meets the cutter for depth perception",
        default=True,
        update=update_ring_visibility,
    )

    live_boolean_preview: BoolProperty(
        name="Live Cut Preview in Viewport",
        description="Uncheck on ultra-dense meshes (1M+ tris) to place and resize holes with zero Boolean calculation until Apply All",
        default=True,
        update=update_live_preview,
    )

    scale_mode: EnumProperty(
        name="Units",
        items=[
            ("AUTO", "Auto-Detect", "Automatically match your model's scale"),
            ("MM", "Millimeters (1 unit = 1mm)", "Standard for 3D print STL files"),
            ("M", "Meters (1 unit = 1m)", "Standard Blender units"),
        ],
        default="AUTO",
        update=update_dimensions_or_facets,
    )

    boolean_solver: EnumProperty(
        name="Solver",
        items=[
            ("FAST", "Fast (No Viewport Lag)", "Fast floating-point Boolean solver ideal for high-poly miniatures"),
            ("MANIFOLD", "Manifold (Fast Solid)", "Fast manifold solver for watertight meshes"),
            ("EXACT", "Exact (High Precision)", "Exact rational arithmetic solver (slower on dense meshes)"),
        ],
        default="FAST",
        update=update_solver_setting,
    )


classes = (
    MagnetProperties,
    MAGNET_OT_place_hole,
    MAGNET_OT_place_at_cursor,
    MAGNET_OT_reposition,
    MAGNET_OT_center_on_curve,
    MAGNET_OT_cut_counterpart,
    MAGNET_OT_apply_controls_to_selected,
    MAGNET_OT_sync_from_selected,
    MAGNET_OT_apply_target_scale,
    MAGNET_OT_remove_selected,
    MAGNET_OT_apply_all,
    MAGNET_OT_clean_cutters,
    MAGNET_PT_main_panel,
)


def _deferred_scene_heal():
    purge_legacy_handlers_and_heal_scene()
    return None


def register():
    ReticleHUD.disable()
    CutterOverlay3D.disable()
    for cls in classes:
        if getattr(cls, "is_registered", False):
            bpy.utils.unregister_class(cls)
        bpy.utils.register_class(cls)
    bpy.types.Scene.magnet_props = bpy.props.PointerProperty(type=MagnetProperties)
    bpy.types.WindowManager.magnet_active = BoolProperty(default=False)
    CutterOverlay3D.enable()
    for handler in list(bpy.app.handlers.depsgraph_update_post):
        h_name = getattr(handler, "__name__", "")
        if h_name == "on_depsgraph_auto_clean_orphans":
            bpy.app.handlers.depsgraph_update_post.remove(handler)
    bpy.app.handlers.depsgraph_update_post.append(on_depsgraph_auto_clean_orphans)
    bpy.app.timers.register(_deferred_scene_heal, first_interval=0.05)


def unregister():
    ReticleHUD.disable()
    CutterOverlay3D.disable()
    for handler in list(bpy.app.handlers.depsgraph_update_post):
        h_name = getattr(handler, "__name__", "")
        if h_name in {"on_depsgraph_update_cleanup", "on_depsgraph_auto_clean_orphans"} or "magnet" in h_name.lower():
            bpy.app.handlers.depsgraph_update_post.remove(handler)
    for cls in reversed(classes):
        if getattr(cls, "is_registered", False):
            bpy.utils.unregister_class(cls)
    if hasattr(bpy.types.Scene, "magnet_props"):
        del bpy.types.Scene.magnet_props
    if hasattr(bpy.types.WindowManager, "magnet_active"):
        del bpy.types.WindowManager.magnet_active


# =========================================================================
# DRAG & DROP AUTO-INSTALLER (WITH LIVE MODULE RELOAD)
# =========================================================================
def auto_install_and_enable():
    existing_mod = sys.modules.get("magnet_cutter")
    if existing_mod is not None and hasattr(existing_mod, "unregister"):
        existing_mod.unregister()

    addons_dir = bpy.utils.user_resource('SCRIPTS', path="addons", create=True)
    target_file = os.path.join(addons_dir, "magnet_cutter.py")
    current_file = os.path.abspath(__file__) if "__file__" in globals() else ""

    if current_file and os.path.exists(current_file):
        same_path = os.path.normpath(current_file).lower() == os.path.normpath(target_file).lower()
        if not same_path:
            should_copy = not os.path.exists(target_file)
            if not should_copy:
                should_copy = (
                    os.path.getsize(current_file) != os.path.getsize(target_file)
                    or os.path.getmtime(current_file) > os.path.getmtime(target_file)
                )
            if should_copy:
                shutil.copy2(current_file, target_file)

    if "magnet_cutter" in bpy.context.preferences.addons and "magnet_cutter" in sys.modules:
        mod = importlib.reload(sys.modules["magnet_cutter"])
        if hasattr(mod, "register"):
            mod.register()
    elif os.path.exists(target_file):
        bpy.ops.preferences.addon_enable(module="magnet_cutter")
        bpy.ops.wm.save_userpref()
    else:
        register()

    purge_legacy_handlers_and_heal_scene()

    def draw_popup(self, context):
        self.layout.label(text="Magnet Hole Cutter v2.3.9 installed & reloaded!", icon='CHECKMARK')
        self.layout.label(text="Open Sidebar (N) > Magnet Tool")

    bpy.context.window_manager.popup_menu(draw_popup, title="Add-on Ready", icon='CHECKMARK')


if __name__ == "__main__":
    auto_install_and_enable()
